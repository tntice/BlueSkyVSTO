﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer5));
            this.lblInsuranceDue = new System.Windows.Forms.Label();
            this.dgvInsuranceDue = new System.Windows.Forms.DataGridView();
            this.InsuranceAmountDue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InsuranceAmountPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblOtherDue = new System.Windows.Forms.Label();
            this.dgvOtherDue = new System.Windows.Forms.DataGridView();
            this.OtherDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherAmountDue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherAmountPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherDueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.dgvClericalFees = new System.Windows.Forms.DataGridView();
            this.lblClericalFees = new System.Windows.Forms.Label();
            this.ClericalAmountDue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClericalAmountPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClericalDueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInsuranceDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOtherDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClericalFees)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInsuranceDue
            // 
            this.lblInsuranceDue.AutoSize = true;
            this.lblInsuranceDue.Location = new System.Drawing.Point(13, 13);
            this.lblInsuranceDue.Name = "lblInsuranceDue";
            this.lblInsuranceDue.Size = new System.Drawing.Size(77, 13);
            this.lblInsuranceDue.TabIndex = 0;
            this.lblInsuranceDue.Text = "Insurance Due";
            // 
            // dgvInsuranceDue
            // 
            this.dgvInsuranceDue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInsuranceDue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.InsuranceAmountDue,
            this.InsuranceAmountPaid,
            this.DueDate});
            this.dgvInsuranceDue.Location = new System.Drawing.Point(107, 13);
            this.dgvInsuranceDue.Name = "dgvInsuranceDue";
            this.dgvInsuranceDue.Size = new System.Drawing.Size(470, 95);
            this.dgvInsuranceDue.TabIndex = 1;
            // 
            // InsuranceAmountDue
            // 
            this.InsuranceAmountDue.HeaderText = "Amount Due";
            this.InsuranceAmountDue.Name = "InsuranceAmountDue";
            this.InsuranceAmountDue.Width = 150;
            // 
            // InsuranceAmountPaid
            // 
            this.InsuranceAmountPaid.HeaderText = "Amount Paid";
            this.InsuranceAmountPaid.Name = "InsuranceAmountPaid";
            this.InsuranceAmountPaid.Width = 150;
            // 
            // DueDate
            // 
            this.DueDate.HeaderText = "Due Date";
            this.DueDate.Name = "DueDate";
            // 
            // lblOtherDue
            // 
            this.lblOtherDue.AutoSize = true;
            this.lblOtherDue.Location = new System.Drawing.Point(13, 262);
            this.lblOtherDue.Name = "lblOtherDue";
            this.lblOtherDue.Size = new System.Drawing.Size(56, 13);
            this.lblOtherDue.TabIndex = 4;
            this.lblOtherDue.Text = "Other Due";
            // 
            // dgvOtherDue
            // 
            this.dgvOtherDue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOtherDue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.OtherDescription,
            this.OtherAmountDue,
            this.OtherAmountPaid,
            this.OtherDueDate});
            this.dgvOtherDue.Location = new System.Drawing.Point(107, 262);
            this.dgvOtherDue.Name = "dgvOtherDue";
            this.dgvOtherDue.Size = new System.Drawing.Size(567, 95);
            this.dgvOtherDue.TabIndex = 5;
            // 
            // OtherDescription
            // 
            this.OtherDescription.HeaderText = "Description";
            this.OtherDescription.Name = "OtherDescription";
            this.OtherDescription.Width = 150;
            // 
            // OtherAmountDue
            // 
            this.OtherAmountDue.HeaderText = "Amount Due";
            this.OtherAmountDue.Name = "OtherAmountDue";
            this.OtherAmountDue.Width = 125;
            // 
            // OtherAmountPaid
            // 
            this.OtherAmountPaid.HeaderText = "Amount Paid";
            this.OtherAmountPaid.Name = "OtherAmountPaid";
            this.OtherAmountPaid.Width = 125;
            // 
            // OtherDueDate
            // 
            this.OtherDueDate.HeaderText = "Due Date";
            this.OtherDueDate.Name = "OtherDueDate";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(410, 375);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(84, 28);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dgvClericalFees
            // 
            this.dgvClericalFees.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClericalFees.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClericalAmountDue,
            this.ClericalAmountPaid,
            this.ClericalDueDate});
            this.dgvClericalFees.Location = new System.Drawing.Point(107, 130);
            this.dgvClericalFees.Name = "dgvClericalFees";
            this.dgvClericalFees.Size = new System.Drawing.Size(470, 110);
            this.dgvClericalFees.TabIndex = 3;
            // 
            // lblClericalFees
            // 
            this.lblClericalFees.AutoSize = true;
            this.lblClericalFees.Location = new System.Drawing.Point(13, 130);
            this.lblClericalFees.Name = "lblClericalFees";
            this.lblClericalFees.Size = new System.Drawing.Size(67, 13);
            this.lblClericalFees.TabIndex = 2;
            this.lblClericalFees.Text = "Clerical Fees";
            // 
            // ClericalAmountDue
            // 
            this.ClericalAmountDue.HeaderText = "Amount Due";
            this.ClericalAmountDue.Name = "ClericalAmountDue";
            this.ClericalAmountDue.Width = 150;
            // 
            // ClericalAmountPaid
            // 
            this.ClericalAmountPaid.HeaderText = "Amount Paid";
            this.ClericalAmountPaid.Name = "ClericalAmountPaid";
            this.ClericalAmountPaid.Width = 150;
            // 
            // ClericalDueDate
            // 
            this.ClericalDueDate.HeaderText = "Due Date";
            this.ClericalDueDate.Name = "ClericalDueDate";
            // 
            // frmNewCustomer5
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.dgvClericalFees);
            this.Controls.Add(this.lblClericalFees);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgvOtherDue);
            this.Controls.Add(this.lblOtherDue);
            this.Controls.Add(this.dgvInsuranceDue);
            this.Controls.Add(this.lblInsuranceDue);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer5";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInsuranceDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOtherDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClericalFees)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInsuranceDue;
        private System.Windows.Forms.DataGridView dgvInsuranceDue;
        private System.Windows.Forms.Label lblOtherDue;
        private System.Windows.Forms.DataGridView dgvOtherDue;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherAmountDue;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherAmountPaid;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherDueDate;
        private System.Windows.Forms.DataGridView dgvClericalFees;
        private System.Windows.Forms.Label lblClericalFees;
        private System.Windows.Forms.DataGridViewTextBoxColumn InsuranceAmountDue;
        private System.Windows.Forms.DataGridViewTextBoxColumn InsuranceAmountPaid;
        private System.Windows.Forms.DataGridViewTextBoxColumn DueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClericalAmountDue;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClericalAmountPaid;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClericalDueDate;
    }
}