﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer3 : Form
    {

#region Constructors

        public frmNewCustomer3()
        {
            InitializeComponent();
        }

#endregion

#region Events

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm4 = new frmNewCustomer6();
                frm4.Show();
                this.Close();
            }

        }

        private void frmNewCustomer3_Load(object sender, EventArgs e)
        {
            try
            {
                txtFinanceAmount.Text = GlobalVars.MyNewCustomer.FinanceAmount.ToString();
                txtTerm.Text = GlobalVars.MyNewCustomer.TermYears.ToString();
                txtInterestRate.Text = GlobalVars.MyNewCustomer.InterestRate.ToString();
                txtPaymentAmount.Text = GlobalVars.MyNewCustomer.PaymentAmount.ToString();
                txtFirstPaymentDue.Text = GlobalVars.MyNewCustomer.FirstPaymentDueDate.ToString();
                txtLastPaymentDue.Text = GlobalVars.MyNewCustomer.LastPaymentDueDate.ToString();
                txtTotalNumOfPayments.Text = GlobalVars.MyNewCustomer.TotalNumPayments.ToString();
                txtLateFeeAmount.Text = GlobalVars.MyNewCustomer.LateFeeAmount.ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void btnBack_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm2 = new frmNewCustomer5();
                frm2.Show();
                this.Close();
            }
        }

#endregion

#region Methods

        private bool SaveForm()
        {
            try
            {
                if (txtFinanceAmount.Text.Length > 0)
                {
                    if (GlobalMethods.IsDouble(txtFinanceAmount.Text))
                    {
                        GlobalVars.MyNewCustomer.FinanceAmount = Convert.ToDouble(txtFinanceAmount.Text);
                    }
                    else
                    {
                        MessageBox.Show("Finance Amount must be a number or empty.");
                        txtFinanceAmount.Focus();
                        txtFinanceAmount.SelectAll();
                        return false;
                    }
                }

                if(txtTerm.Text.Length > 0)
                {
                    if (GlobalMethods.IsDouble(txtTerm.Text))
                    {
                        GlobalVars.MyNewCustomer.TermYears = Convert.ToDouble(txtTerm.Text);
                    }
                    else
                    {
                        MessageBox.Show("Term must be a number or empty.");
                        txtTerm.Focus();
                        txtTerm.SelectAll();
                        return false;
                    }
                }
                if(txtInterestRate.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtInterestRate.Text))
                    {
                        GlobalVars.MyNewCustomer.InterestRate = Convert.ToDouble(txtInterestRate.Text);
                    }
                    else
                    {
                        MessageBox.Show("Interest Rate must be a number.");
                        txtInterestRate.Focus();
                        txtInterestRate.SelectAll();
                        return false;
                    }
                }
                if(txtPaymentAmount.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtPaymentAmount.Text))
                    {
                        GlobalVars.MyNewCustomer.PaymentAmount = Convert.ToDouble(txtPaymentAmount.Text);
                    }
                    else
                    {
                        MessageBox.Show("Payment Amount must be a number.");
                        txtPaymentAmount.Focus();
                        txtPaymentAmount.SelectAll();
                        return false;
                    }
                }

                if (txtFirstPaymentDue.Text.Length > 0)
                {
                    if (GlobalMethods.IsValidDateTime(txtFirstPaymentDue.Text))
                    {
                        GlobalVars.MyNewCustomer.FirstPaymentDueDate = txtFirstPaymentDue.Text;
                    }
                    else
                    {
                        MessageBox.Show("First Payment Due Date is not a valid Date.");
                        txtFirstPaymentDue.Focus();
                        txtFirstPaymentDue.SelectAll();
                        return false;
                    }
                }

                if(txtLastPaymentDue.Text.Length > 0)
                {
                    if(GlobalMethods.IsValidDateTime(txtLastPaymentDue.Text))
                    {
                        GlobalVars.MyNewCustomer.LastPaymentDueDate = txtLastPaymentDue.Text;
                    }
                    else
                    {
                        MessageBox.Show("Last Payment Due Date is not a valid Date.");
                        txtLastPaymentDue.Focus();
                        txtLastPaymentDue.SelectAll();
                        return false;
                    }
                }

                if(txtTotalNumOfPayments.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtTotalNumOfPayments.Text))
                    {
                        GlobalVars.MyNewCustomer.TotalNumPayments = Convert.ToDouble(txtTotalNumOfPayments.Text);
                    }
                    else
                    {
                        MessageBox.Show("Total Number of Payments must be a number.");
                        txtTotalNumOfPayments.Focus();
                        txtTotalNumOfPayments.SelectAll();
                        return false;
                    }
                }

                if(txtLateFeeAmount.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtLateFeeAmount.Text))
                    {
                        GlobalVars.MyNewCustomer.LateFeeAmount = Convert.ToDouble(txtLateFeeAmount.Text);
                    }
                    else
                    {
                        MessageBox.Show("Late Fee Amount must be a number.");
                        txtLateFeeAmount.Focus();
                        txtLateFeeAmount.SelectAll();
                        return false;
                    }
                }

                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;
        }

        #endregion
        
        private void btnCalculateFinanceAmount_Click(object sender, EventArgs e)
        {
            txtFinanceAmount.Text = GlobalVars.MyNewCustomer.TotalFinanceAmount().ToString();
        }
    }
}
