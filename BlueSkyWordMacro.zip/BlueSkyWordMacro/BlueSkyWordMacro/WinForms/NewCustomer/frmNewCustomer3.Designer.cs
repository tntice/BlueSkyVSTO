﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer3));
            this.lblFinanceAmount = new System.Windows.Forms.Label();
            this.txtFinanceAmount = new System.Windows.Forms.TextBox();
            this.lblTerm = new System.Windows.Forms.Label();
            this.txtTerm = new System.Windows.Forms.TextBox();
            this.lblInterestRate = new System.Windows.Forms.Label();
            this.txtInterestRate = new System.Windows.Forms.TextBox();
            this.lblPaymentAmount = new System.Windows.Forms.Label();
            this.txtPaymentAmount = new System.Windows.Forms.TextBox();
            this.lblFirstPaymentDue = new System.Windows.Forms.Label();
            this.txtFirstPaymentDue = new System.Windows.Forms.TextBox();
            this.lblLastPaymentDue = new System.Windows.Forms.Label();
            this.txtLastPaymentDue = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTotalNumOfPayments = new System.Windows.Forms.TextBox();
            this.lblLateFeeAmount = new System.Windows.Forms.Label();
            this.txtLateFeeAmount = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnCalculateFinanceAmount = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFinanceAmount
            // 
            this.lblFinanceAmount.AutoSize = true;
            this.lblFinanceAmount.Location = new System.Drawing.Point(12, 18);
            this.lblFinanceAmount.Name = "lblFinanceAmount";
            this.lblFinanceAmount.Size = new System.Drawing.Size(84, 13);
            this.lblFinanceAmount.TabIndex = 0;
            this.lblFinanceAmount.Text = "Finance Amount";
            // 
            // txtFinanceAmount
            // 
            this.txtFinanceAmount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFinanceAmount.Location = new System.Drawing.Point(125, 15);
            this.txtFinanceAmount.Name = "txtFinanceAmount";
            this.txtFinanceAmount.Size = new System.Drawing.Size(184, 20);
            this.txtFinanceAmount.TabIndex = 1;
            // 
            // lblTerm
            // 
            this.lblTerm.AutoSize = true;
            this.lblTerm.Location = new System.Drawing.Point(12, 45);
            this.lblTerm.Name = "lblTerm";
            this.lblTerm.Size = new System.Drawing.Size(67, 13);
            this.lblTerm.TabIndex = 2;
            this.lblTerm.Text = "Term (Years)";
            // 
            // txtTerm
            // 
            this.txtTerm.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTerm.Location = new System.Drawing.Point(125, 42);
            this.txtTerm.Name = "txtTerm";
            this.txtTerm.Size = new System.Drawing.Size(184, 20);
            this.txtTerm.TabIndex = 3;
            // 
            // lblInterestRate
            // 
            this.lblInterestRate.AutoSize = true;
            this.lblInterestRate.Location = new System.Drawing.Point(12, 71);
            this.lblInterestRate.Name = "lblInterestRate";
            this.lblInterestRate.Size = new System.Drawing.Size(98, 13);
            this.lblInterestRate.TabIndex = 4;
            this.lblInterestRate.Text = "Interest Rate (0.12)";
            // 
            // txtInterestRate
            // 
            this.txtInterestRate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInterestRate.Location = new System.Drawing.Point(125, 68);
            this.txtInterestRate.Name = "txtInterestRate";
            this.txtInterestRate.Size = new System.Drawing.Size(184, 20);
            this.txtInterestRate.TabIndex = 5;
            this.txtInterestRate.Text = "0.12";
            // 
            // lblPaymentAmount
            // 
            this.lblPaymentAmount.AutoSize = true;
            this.lblPaymentAmount.Location = new System.Drawing.Point(12, 98);
            this.lblPaymentAmount.Name = "lblPaymentAmount";
            this.lblPaymentAmount.Size = new System.Drawing.Size(87, 13);
            this.lblPaymentAmount.TabIndex = 6;
            this.lblPaymentAmount.Text = "Payment Amount";
            // 
            // txtPaymentAmount
            // 
            this.txtPaymentAmount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPaymentAmount.Location = new System.Drawing.Point(125, 95);
            this.txtPaymentAmount.Name = "txtPaymentAmount";
            this.txtPaymentAmount.Size = new System.Drawing.Size(184, 20);
            this.txtPaymentAmount.TabIndex = 7;
            // 
            // lblFirstPaymentDue
            // 
            this.lblFirstPaymentDue.AutoSize = true;
            this.lblFirstPaymentDue.Location = new System.Drawing.Point(12, 125);
            this.lblFirstPaymentDue.Name = "lblFirstPaymentDue";
            this.lblFirstPaymentDue.Size = new System.Drawing.Size(88, 13);
            this.lblFirstPaymentDue.TabIndex = 8;
            this.lblFirstPaymentDue.Text = "1st Payment Due";
            // 
            // txtFirstPaymentDue
            // 
            this.txtFirstPaymentDue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFirstPaymentDue.Location = new System.Drawing.Point(125, 122);
            this.txtFirstPaymentDue.Name = "txtFirstPaymentDue";
            this.txtFirstPaymentDue.Size = new System.Drawing.Size(184, 20);
            this.txtFirstPaymentDue.TabIndex = 9;
            // 
            // lblLastPaymentDue
            // 
            this.lblLastPaymentDue.AutoSize = true;
            this.lblLastPaymentDue.Location = new System.Drawing.Point(12, 152);
            this.lblLastPaymentDue.Name = "lblLastPaymentDue";
            this.lblLastPaymentDue.Size = new System.Drawing.Size(94, 13);
            this.lblLastPaymentDue.TabIndex = 10;
            this.lblLastPaymentDue.Text = "Last Payment Due";
            // 
            // txtLastPaymentDue
            // 
            this.txtLastPaymentDue.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLastPaymentDue.Location = new System.Drawing.Point(125, 149);
            this.txtLastPaymentDue.Name = "txtLastPaymentDue";
            this.txtLastPaymentDue.Size = new System.Drawing.Size(184, 20);
            this.txtLastPaymentDue.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Total # of Payments";
            // 
            // txtTotalNumOfPayments
            // 
            this.txtTotalNumOfPayments.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotalNumOfPayments.Location = new System.Drawing.Point(124, 176);
            this.txtTotalNumOfPayments.Name = "txtTotalNumOfPayments";
            this.txtTotalNumOfPayments.Size = new System.Drawing.Size(185, 20);
            this.txtTotalNumOfPayments.TabIndex = 13;
            // 
            // lblLateFeeAmount
            // 
            this.lblLateFeeAmount.AutoSize = true;
            this.lblLateFeeAmount.Location = new System.Drawing.Point(12, 206);
            this.lblLateFeeAmount.Name = "lblLateFeeAmount";
            this.lblLateFeeAmount.Size = new System.Drawing.Size(88, 13);
            this.lblLateFeeAmount.TabIndex = 14;
            this.lblLateFeeAmount.Text = "Late Fee Amount";
            // 
            // txtLateFeeAmount
            // 
            this.txtLateFeeAmount.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLateFeeAmount.Location = new System.Drawing.Point(125, 203);
            this.txtLateFeeAmount.Name = "txtLateFeeAmount";
            this.txtLateFeeAmount.Size = new System.Drawing.Size(184, 20);
            this.txtLateFeeAmount.TabIndex = 15;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(410, 375);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(84, 28);
            this.btnBack.TabIndex = 18;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 19;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 20;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnCalculateFinanceAmount
            // 
            this.btnCalculateFinanceAmount.Location = new System.Drawing.Point(315, 13);
            this.btnCalculateFinanceAmount.Name = "btnCalculateFinanceAmount";
            this.btnCalculateFinanceAmount.Size = new System.Drawing.Size(75, 23);
            this.btnCalculateFinanceAmount.TabIndex = 21;
            this.btnCalculateFinanceAmount.Text = "Calculate";
            this.btnCalculateFinanceAmount.UseVisualStyleBackColor = true;
            this.btnCalculateFinanceAmount.Click += new System.EventHandler(this.btnCalculateFinanceAmount_Click);
            // 
            // frmNewCustomer3
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.btnCalculateFinanceAmount);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtLateFeeAmount);
            this.Controls.Add(this.lblLateFeeAmount);
            this.Controls.Add(this.txtTotalNumOfPayments);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtLastPaymentDue);
            this.Controls.Add(this.lblLastPaymentDue);
            this.Controls.Add(this.txtFirstPaymentDue);
            this.Controls.Add(this.lblFirstPaymentDue);
            this.Controls.Add(this.txtPaymentAmount);
            this.Controls.Add(this.lblPaymentAmount);
            this.Controls.Add(this.txtInterestRate);
            this.Controls.Add(this.lblInterestRate);
            this.Controls.Add(this.txtTerm);
            this.Controls.Add(this.lblTerm);
            this.Controls.Add(this.txtFinanceAmount);
            this.Controls.Add(this.lblFinanceAmount);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFinanceAmount;
        private System.Windows.Forms.TextBox txtFinanceAmount;
        private System.Windows.Forms.Label lblTerm;
        private System.Windows.Forms.TextBox txtTerm;
        private System.Windows.Forms.Label lblInterestRate;
        private System.Windows.Forms.TextBox txtInterestRate;
        private System.Windows.Forms.Label lblPaymentAmount;
        private System.Windows.Forms.TextBox txtPaymentAmount;
        private System.Windows.Forms.Label lblFirstPaymentDue;
        private System.Windows.Forms.TextBox txtFirstPaymentDue;
        private System.Windows.Forms.Label lblLastPaymentDue;
        private System.Windows.Forms.TextBox txtLastPaymentDue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTotalNumOfPayments;
        private System.Windows.Forms.Label lblLateFeeAmount;
        private System.Windows.Forms.TextBox txtLateFeeAmount;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnCalculateFinanceAmount;
    }
}