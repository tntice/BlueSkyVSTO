﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using Microsoft.Office.Interop;
using System.IO;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer7 : Form
    {
        #region Constructors

        public frmNewCustomer7()
        {
            InitializeComponent();
        }

        #endregion

        #region Events

        private void frmNewCustomer7_Load(object sender, EventArgs e)
        {
            txtFolder.Text = GlobalVars.NewCustomerFolder.ToString();

            if(!(Directory.Exists(txtFolder.Text)))
            {
                MessageBox.Show("Directory doesn't exist. Please select a valid folder.");
            }
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            try
            {
                if (SaveForm())
                {
                    btnFinish.Enabled = false;

                    Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                    configuration.AppSettings.Settings["MowreyNumber"].Value = (GlobalVars.MowreyNumber + 1).ToString();
                    configuration.AppSettings.Settings["NewCustomerFolder"].Value = GlobalVars.NewCustomerFolder.ToString();

                    configuration.Save();
                    ConfigurationManager.RefreshSection("appSettings");

                    BlueSkyDocuments.CreateLandSaleSummary();
                    BlueSkyDocuments.CreatePaysheet();
                    BlueSkyDocuments.CreateAmortizationSheet();

                    btnFinish.Enabled = true;

                    MessageBox.Show("Documents created successfully !");

                    this.Close();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                btnFinish.Enabled = true;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (SaveForm())
            {
                Form frm6 = new frmNewCustomer6();
                frm6.Show();
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            //this.fldDialogForms.RootFolder = Environment.SpecialFolder.Personal;
            this.fldDialogForms.RootFolder = Environment.SpecialFolder.MyComputer;
            DialogResult result = fldDialogForms.ShowDialog();
            if (result == DialogResult.OK)
            {
                txtFolder.Text = fldDialogForms.SelectedPath;

            }

        }

        #endregion

        #region Methods

        private bool SaveForm()
        {
            try
            {
                GlobalVars.NewCustomerFolder = txtFolder.Text.ToString();
                if (!(Directory.Exists(txtFolder.Text)))
                {
                    MessageBox.Show("Directory doesn't exist. Please select a valid folder.");
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;
        }

        #endregion

    }
}
