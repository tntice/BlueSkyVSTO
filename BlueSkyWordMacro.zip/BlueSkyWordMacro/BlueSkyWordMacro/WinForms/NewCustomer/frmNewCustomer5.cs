﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer5 : Form
    {

#region Constructors

        public frmNewCustomer5()
        {
            InitializeComponent();
        }

#endregion

#region Events

        private void btnBack_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm4 = new frmNewCustomer4();
                frm4.Show();
                this.Close();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm6 = new frmNewCustomer3();
                frm6.Show();
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }
        
        private void frmNewCustomer5_Load(object sender, EventArgs e)
        {
            try
            {
                foreach (InsuranceDue insDue in GlobalVars.MyNewCustomer.InsuranceDues)
                {
                    dgvInsuranceDue.Rows.Add(insDue.InsuranceDueAmount,insDue.InsurancePaidAmount, insDue.DueDate);
                }
               
                foreach (OtherDue othDue in GlobalVars.MyNewCustomer.OtherDues)
                {
                    dgvOtherDue.Rows.Add(othDue.Description, othDue.OtherDueAmount, othDue.OtherPaidAmount, othDue.DueDate);
                }

                foreach (ClericalFee clrFee in GlobalVars.MyNewCustomer.ClericalFees)
                {
                    dgvClericalFees.Rows.Add(clrFee.ClericalFeeDueAmount, clrFee.ClericalFeePaidAmount, clrFee.DueDate);
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

 #endregion

#region Methods

        private bool SaveForm()
        {
            try
            {
                GlobalVars.MyNewCustomer.InsuranceDues.Clear();
                GlobalVars.MyNewCustomer.OtherDues.Clear();
                GlobalVars.MyNewCustomer.ClericalFees.Clear();

                foreach (DataGridViewRow dr in dgvInsuranceDue.Rows)
                {
                    InsuranceDue insDue = new InsuranceDue();
                    if (!(dr.Cells["InsuranceAmountDue"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["InsuranceAmountDue"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["InsuranceAmountDue"].Value.ToString()))
                            {
                                insDue.InsuranceDueAmount = Convert.ToDouble(dr.Cells["InsuranceAmountDue"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Insurance Due Amount must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["InsuranceAmountPaid"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["InsuranceAmountPaid"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["InsuranceAmountPaid"].Value.ToString()))
                            {
                                insDue.InsurancePaidAmount = Convert.ToDouble(dr.Cells["InsuranceAmountPaid"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Insurance Paid Amount must be a number.");
                                return false;
                            }
                        }
                    }
                    if (!(dr.Cells["DueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["DueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["DueDate"].Value.ToString()))
                            {
                                insDue.DueDate = dr.Cells["DueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Insurance Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if ((insDue.InsuranceDueAmount > 0) || (insDue.InsurancePaidAmount > 0))
                    {
                        GlobalVars.MyNewCustomer.InsuranceDues.Add(insDue);
                    }
                }

                foreach (DataGridViewRow dr in dgvOtherDue.Rows)
                {
                    OtherDue othDue = new OtherDue();

                    if (!(dr.Cells["OtherDescription"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["OtherDescription"].Value.ToString())))
                        {
                            othDue.Description = dr.Cells["OtherDescription"].Value.ToString();
                        }
                    }

                    if (!(dr.Cells["OtherAmountDue"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["OtherAmountDue"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["OtherAmountDue"].Value.ToString()))
                            {
                                othDue.OtherDueAmount = Convert.ToDouble(dr.Cells["OtherAmountDue"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Other Due Amount must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["OtherAmountPaid"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["OtherAmountPaid"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["OtherAmountPaid"].Value.ToString()))
                            {
                                othDue.OtherPaidAmount = Convert.ToDouble(dr.Cells["OtherAmountPaid"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Other Paid Amount must be a number.");
                                return false;
                            }
                        }
                    }
                    if (!(dr.Cells["OtherDueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["OtherDueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["OtherDueDate"].Value.ToString()))
                            {
                                othDue.DueDate = dr.Cells["OtherDueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Other Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if ((othDue.OtherDueAmount > 0) || (othDue.OtherPaidAmount > 0))
                    {
                        GlobalVars.MyNewCustomer.OtherDues.Add(othDue);
                    }
                }

                
                foreach (DataGridViewRow dr in dgvClericalFees.Rows)
                {
                    ClericalFee clrFee = new ClericalFee();

                    if (!(dr.Cells["ClericalAmountDue"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["ClericalAmountDue"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["ClericalAmountDue"].Value.ToString()))
                            {
                                clrFee.ClericalFeeDueAmount = Convert.ToDouble(dr.Cells["ClericalAmountDue"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Clerical Fee Amount Due must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["ClericalAmountPaid"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["ClericalAmountPaid"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["ClericalAmountPaid"].Value.ToString()))
                            {
                                clrFee.ClericalFeePaidAmount = Convert.ToDouble(dr.Cells["ClericalAmountPaid"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Clerical Fee Amount Paid must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["ClericalDueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["ClericalDueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["ClericalDueDate"].Value.ToString()))
                            {
                                clrFee.DueDate = dr.Cells["ClericalDueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Clerical Fee Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if (clrFee.ClericalFeeDueAmount > 0 || clrFee.ClericalFeePaidAmount > 0)
                    {
                        GlobalVars.MyNewCustomer.ClericalFees.Add(clrFee);
                    }

                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;

        }


#endregion

    }
}
