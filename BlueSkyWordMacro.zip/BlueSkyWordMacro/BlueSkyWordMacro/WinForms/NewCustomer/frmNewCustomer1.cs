﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer1 : Form
    {
        public frmNewCustomer1()
        {
            InitializeComponent();
        }

        private void frmNewCustomer1_Load(object sender, EventArgs e)
        {
            try
            {
                PopulateCounty();
                PopulateForm();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (GlobalMethods.IsValidDateTime(this.txtDate.Text))
                {
                    GlobalVars.MyNewCustomer.SellDate = Convert.ToDateTime(this.txtDate.Text);
                }
                else
                {
                    MessageBox.Show("Date is not a valid date.  Please enter a valid date value.");
                    txtDate.Focus();
                    return;
                }

                GlobalVars.MyNewCustomer.Description = txtDescription.Text;
                GlobalVars.MyNewCustomer.TownshipBorough = txtTownship.Text;

                if (cboCounty.SelectedItem != null)
                {
                    GlobalVars.MyNewCustomer.County = cboCounty.SelectedItem.ToString();
                }
                else
                {
                    if (!(string.IsNullOrEmpty(cboCounty.Text)))
                    {
                        GlobalVars.MyNewCustomer.County = cboCounty.Text;
                    }
                    else
                    {
                        GlobalVars.MyNewCustomer.County = string.Empty;
                    }

                }

                GlobalVars.MyNewCustomer.MowreyNumber = txtMowreyNumber.Text;
                GlobalVars.MyNewCustomer.Seller = txtSeller.Text;
                GlobalVars.MyNewCustomer.Buyer = txtBuyer.Text;
                GlobalVars.MyNewCustomer.Address1 = txtStreetAddress1.Text;
                GlobalVars.MyNewCustomer.Address2 = txtStreetAddress2.Text;
                GlobalVars.MyNewCustomer.CityStateZip = txtCityStateZip.Text;
                GlobalVars.MyNewCustomer.PhoneNumber = txtPhoneNumber.Text;
                GlobalVars.MyNewCustomer.Email = txtEmail.Text;

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

                frmNewCustomer2 frm2 = new frmNewCustomer2();
                frm2.Show();
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }

        private void btnChangeMowreyNumber_Click(object sender, EventArgs e)
        {
            frmPrompt promptDlg = new frmPrompt();

            promptDlg.ShowDialog();
            if (promptDlg.DialogResult == DialogResult.OK)
            {
                string strValue = promptDlg.Text;
                txtMowreyNumber.Text = strValue;
                GlobalVars.MowreyNumber = Convert.ToInt32(strValue);
                GlobalMethods.SaveMowreyNumber();
            }
        }
        
        private void btnTestData_Click(object sender, EventArgs e)
        {
            GlobalMethods.PopulateTestData();
            PopulateForm();

        }

        private void PopulateCounty()
        {
            foreach(var county in Enum.GetValues(typeof( Counties)))
            {
                cboCounty.Items.Add(county);
            }
        }

        private void PopulateForm()
        {
            try
            {

                txtMowreyNumber.Text = GlobalVars.MowreyNumber.ToString();

                txtDate.Text = GlobalVars.MyNewCustomer.SellDate.ToShortDateString();
                txtDescription.Text = GlobalVars.MyNewCustomer.Description;
                txtTownship.Text = GlobalVars.MyNewCustomer.TownshipBorough;
                if (!(string.IsNullOrEmpty(GlobalVars.MyNewCustomer.County)))
                {
                    cboCounty.SelectedText = GlobalVars.MyNewCustomer.County.ToString();
                }
                txtSeller.Text = GlobalVars.MyNewCustomer.Seller;
                txtBuyer.Text = GlobalVars.MyNewCustomer.Buyer;
                txtStreetAddress1.Text = GlobalVars.MyNewCustomer.Address1;
                txtStreetAddress2.Text = GlobalVars.MyNewCustomer.Address2;
                txtCityStateZip.Text = GlobalVars.MyNewCustomer.CityStateZip;
                txtPhoneNumber.Text = GlobalVars.MyNewCustomer.PhoneNumber;
                txtEmail.Text = GlobalVars.MyNewCustomer.Email;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
