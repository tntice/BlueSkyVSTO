﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer6 : Form
    {

#region Constructors

        public frmNewCustomer6()
        {
            InitializeComponent();
        }


        #endregion

#region Events

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (SaveForm())
            {
                Form frm7 = new frmNewCustomer7();
                frm7.Show();
                this.Close();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (SaveForm())
            {
                Form frm5 = new frmNewCustomer3();
                frm5.Show();
                this.Close();
            }
        }

        private void frmNewCustomer6_Load(object sender, EventArgs e)
        {
            try
            {
                txtAssessmentNumber.Text = GlobalVars.MyNewCustomer.AssessmentNumber.ToString();
                txtPrincipalPerMonth.Text = GlobalVars.MyNewCustomer.PrincipalPerMonth.ToString();
                txtInterestPerMonth.Text = GlobalVars.MyNewCustomer.InterestPerMonth.ToString();
                txtTotalActualPrice.Text = GlobalVars.MyNewCustomer.TotalActualPrice.ToString();
                txtSellersCost.Text = GlobalVars.MyNewCustomer.SellersCost.ToString();
                txtSellersPurchaseDate.Text = GlobalVars.MyNewCustomer.SellersPurchaseDate.ToString();
                txtSellersDBReference.Text = GlobalVars.MyNewCustomer.SellersDBReference.ToString();
                txtSellersProfit.Text = GlobalVars.MyNewCustomer.SellersProfit.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

#endregion

#region Methods

        private bool SaveForm()
        {
            try
            {
                GlobalVars.MyNewCustomer.AssessmentNumber = txtAssessmentNumber.Text.ToString();

                if (txtPrincipalPerMonth.Text.Length > 0)
                {
                    if (GlobalMethods.IsDouble(txtPrincipalPerMonth.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.PrincipalPerMonth = Convert.ToDouble(txtPrincipalPerMonth.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Principal per month must be a number or blank.");
                        txtPrincipalPerMonth.Focus();
                        txtPrincipalPerMonth.SelectAll();
                        return false;
                    }
                }
                if(txtInterestPerMonth.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtInterestPerMonth.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.InterestPerMonth = Convert.ToDouble(txtInterestPerMonth.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Interest Per Month must be a number or blank.");
                        txtInterestPerMonth.Focus();
                        txtInterestPerMonth.SelectAll();
                        return false;
                    }
                }

                if(txtTotalActualPrice.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtTotalActualPrice.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.TotalActualPrice = Convert.ToDouble(txtTotalActualPrice.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Total Actual Price must be a number or blank.");
                        txtTotalActualPrice.Focus();
                        txtTotalActualPrice.SelectAll();
                        return false;
                    }
                }
                
                if(txtSellersCost.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtSellersCost.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.SellersCost = Convert.ToDouble(txtSellersCost.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Seller's Cost must be a number or blank.");
                        txtSellersCost.Focus();
                        txtSellersCost.SelectAll();
                        return false;
                    }
                }

                if(txtSellersProfit.Text.Length > 0)
                {
                    if(GlobalMethods.IsDouble(txtSellersProfit.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.SellersProfit = Convert.ToDouble(txtSellersProfit.Text.ToString());
                    }
                    else
                    {
                        MessageBox.Show("Seller's Profit must be a number or blank.");
                        txtSellersProfit.Focus();
                        txtSellersProfit.SelectAll();
                        return false;
                    }
                }

                if(txtSellersPurchaseDate.Text.Length > 0)
                {
                    if (GlobalMethods.IsValidDateTime(txtSellersPurchaseDate.Text.ToString()))
                    {
                        GlobalVars.MyNewCustomer.SellersPurchaseDate = txtSellersPurchaseDate.Text.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Seller's Purchase Date but be in the form of a date or blank.");
                        txtSellersPurchaseDate.Focus();
                        txtSellersPurchaseDate.SelectAll();
                        return false;
                    }
                }

                GlobalVars.MyNewCustomer.SellersDBReference = txtSellersDBReference.Text.ToString();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;
        }

        #endregion

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            txtTotalActualPrice.Text = Convert.ToString( GlobalVars.MyNewCustomer.TotalFinanceAmount() + GlobalVars.MyNewCustomer.TotalDownpayment());
        }

        private void btnCalculateSellersProfit_Click(object sender, EventArgs e)
        {
            try
            {
                txtSellersProfit.Text = Convert.ToString(Convert.ToDouble(txtTotalActualPrice.Text) - Convert.ToDouble(txtSellersCost.Text));
            }
            catch
            {
                txtSellersProfit.Text = string.Empty;
            }
            
        }
    }
}
