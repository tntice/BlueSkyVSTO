﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer4 : Form
    {

#region Constructors

        public frmNewCustomer4()
        {
            InitializeComponent();
        }

#endregion

#region Events

        private void btnBack_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm3 = new frmNewCustomer2();
                frm3.Show();
                this.Close();
            }
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if(SaveForm())
            {
                Form frm5 = new frmNewCustomer5();
                frm5.Show();
                this.Close();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }
        
        private void frmNewCustomer4_Load(object sender, EventArgs e)
        {
            foreach (TaxesDue txDue in GlobalVars.MyNewCustomer.TaxesDues)
            {
                dgvTaxesDue.Rows.Add(txDue.TaxesDueAmount, txDue.TaxesPaidAmount, txDue.DueDate);
            }
            
            foreach(SewerTapFeeDue stDue in GlobalVars.MyNewCustomer.SewerTapFeeDues)
            {
                dgvSewerTapFeeDue.Rows.Add(stDue.SewerTapFeeDueAmount, stDue.SewerTapFeePaidAmount, stDue.DueDate);
            }

            foreach(SewerSecurityDepositDue ssDepDue in GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues)
            {
                dgvSewerSecurityDepositDue.Rows.Add(ssDepDue.SewerSecurityDepositDueAmount, ssDepDue.SewerSecurityDepositPaidAmount, ssDepDue.DueDate);
            }
        }

 #endregion

#region Methods

        private bool SaveForm()
        {
            try
            {
                GlobalVars.MyNewCustomer.TaxesDues.Clear();
                GlobalVars.MyNewCustomer.SewerTapFeeDues.Clear();
                GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues.Clear();

                foreach(DataGridViewRow dr in dgvTaxesDue.Rows)
                {
                    TaxesDue txDue = new TaxesDue();
                    if (!(dr.Cells["AmountDue"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["AmountDue"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["AmountDue"].Value.ToString()))
                            {
                                txDue.TaxesDueAmount = Convert.ToDouble(dr.Cells["AmountDue"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Tax Amount Due must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["AmountPaid"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["AmountPaid"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["AmountPaid"].Value.ToString()))
                            {
                                txDue.TaxesPaidAmount = Convert.ToDouble(dr.Cells["AmountPaid"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Tax Amount Paid must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["DueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["DueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["DueDate"].Value.ToString()))
                            {
                                txDue.DueDate = dr.Cells["DueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Taxes Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if ((txDue.TaxesDueAmount > 0) || (txDue.TaxesPaidAmount > 0))
                    {
                        GlobalVars.MyNewCustomer.TaxesDues.Add(txDue);
                    }
                }

                foreach(DataGridViewRow dr in dgvSewerTapFeeDue.Rows)
                {
                    SewerTapFeeDue tDue = new SewerTapFeeDue();
                    if (!(dr.Cells["SewerTapFeeDueAmount"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["SewerTapFeeDueAmount"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["SewerTapFeeDueAmount"].Value.ToString()))
                            {
                                tDue.SewerTapFeeDueAmount = Convert.ToDouble(dr.Cells["SewerTapFeeDueAmount"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Tap Fee Due Amount must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["SewerTapFeePaidAmount"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["SewerTapFeePaidAmount"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["SewerTapFeePaidAmount"].Value.ToString()))
                            {
                                tDue.SewerTapFeePaidAmount = Convert.ToDouble(dr.Cells["SewerTapFeePaidAmount"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Tap Fee Paid Amount must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["SewerTapFeeDueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["SewerTapFeeDueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["SewerTapFeeDueDate"].Value.ToString()))
                            {
                                tDue.DueDate = dr.Cells["SewerTapFeeDueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Tap Fee Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if ((tDue.SewerTapFeeDueAmount > 0) || (tDue.SewerTapFeePaidAmount > 0))
                    {
                        GlobalVars.MyNewCustomer.SewerTapFeeDues.Add(tDue);
                    }
                }

                foreach(DataGridViewRow dr in dgvSewerSecurityDepositDue.Rows)
                {
                    SewerSecurityDepositDue ssDepDue = new SewerSecurityDepositDue();


                    if (!(dr.Cells["SewerSecurityAmountDue"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["SewerSecurityAmountDue"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["SewerSecurityAmountDue"].Value.ToString()))
                            {
                                ssDepDue.SewerSecurityDepositDueAmount = Convert.ToDouble(dr.Cells["SewerSecurityAmountDue"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Security Deposit Due Amount must be a number.");
                                return false;
                            }
                        }
                    }

                    if (!(dr.Cells["SewerSecurityAmountPaid"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["SewerSecurityAmountPaid"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["SewerSecurityAmountPaid"].Value.ToString()))
                            {
                                ssDepDue.SewerSecurityDepositPaidAmount = Convert.ToDouble(dr.Cells["SewerSecurityAmountPaid"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Security Deposit Paid Amount must be a number.");
                                return false;
                            }
                        }
                    }


                    if (!(dr.Cells["WaterSecurityDepositDueDate"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["WaterSecurityDepositDueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["WaterSecurityDepositDueDate"].Value.ToString()))
                            {
                                ssDepDue.DueDate = dr.Cells["WaterSecurityDepositDueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Water/Sewer Security Deposit Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }

                    if ((ssDepDue.SewerSecurityDepositDueAmount > 0)||(ssDepDue.SewerSecurityDepositPaidAmount > 0))
                    {
                        GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues.Add(ssDepDue);
                    }
                }


            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;

        }


#endregion

    }
}
