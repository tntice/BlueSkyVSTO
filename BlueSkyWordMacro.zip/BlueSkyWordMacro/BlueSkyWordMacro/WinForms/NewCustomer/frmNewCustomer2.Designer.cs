﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer2));
            this.lblCashPrice = new System.Windows.Forms.Label();
            this.txtCashPrice = new System.Windows.Forms.TextBox();
            this.lblTypeRental = new System.Windows.Forms.Label();
            this.lblDownPayment = new System.Windows.Forms.Label();
            this.dgvDownPayment = new System.Windows.Forms.DataGridView();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTotalDownPayment = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.grpType = new System.Windows.Forms.GroupBox();
            this.rbRental = new System.Windows.Forms.RadioButton();
            this.rbRegular = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDownPayment)).BeginInit();
            this.grpType.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCashPrice
            // 
            this.lblCashPrice.AutoSize = true;
            this.lblCashPrice.Location = new System.Drawing.Point(13, 13);
            this.lblCashPrice.Name = "lblCashPrice";
            this.lblCashPrice.Size = new System.Drawing.Size(58, 13);
            this.lblCashPrice.TabIndex = 0;
            this.lblCashPrice.Text = "Cash Price";
            // 
            // txtCashPrice
            // 
            this.txtCashPrice.Location = new System.Drawing.Point(153, 10);
            this.txtCashPrice.Name = "txtCashPrice";
            this.txtCashPrice.Size = new System.Drawing.Size(146, 20);
            this.txtCashPrice.TabIndex = 1;
            // 
            // lblTypeRental
            // 
            this.lblTypeRental.AutoSize = true;
            this.lblTypeRental.Location = new System.Drawing.Point(12, 61);
            this.lblTypeRental.Name = "lblTypeRental";
            this.lblTypeRental.Size = new System.Drawing.Size(131, 13);
            this.lblTypeRental.TabIndex = 2;
            this.lblTypeRental.Text = "Type (Purchase or Rental)";
            // 
            // lblDownPayment
            // 
            this.lblDownPayment.AutoSize = true;
            this.lblDownPayment.Location = new System.Drawing.Point(13, 86);
            this.lblDownPayment.Name = "lblDownPayment";
            this.lblDownPayment.Size = new System.Drawing.Size(84, 13);
            this.lblDownPayment.TabIndex = 4;
            this.lblDownPayment.Text = "Down Payments";
            // 
            // dgvDownPayment
            // 
            this.dgvDownPayment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDownPayment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Amount,
            this.DueDate});
            this.dgvDownPayment.Location = new System.Drawing.Point(153, 86);
            this.dgvDownPayment.Name = "dgvDownPayment";
            this.dgvDownPayment.Size = new System.Drawing.Size(373, 228);
            this.dgvDownPayment.TabIndex = 5;
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.Width = 200;
            // 
            // DueDate
            // 
            this.DueDate.HeaderText = "Due Date";
            this.DueDate.Name = "DueDate";
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(410, 375);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(84, 28);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 332);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Total Down Payment";
            // 
            // lblTotalDownPayment
            // 
            this.lblTotalDownPayment.AutoSize = true;
            this.lblTotalDownPayment.Location = new System.Drawing.Point(153, 332);
            this.lblTotalDownPayment.Name = "lblTotalDownPayment";
            this.lblTotalDownPayment.Size = new System.Drawing.Size(63, 13);
            this.lblTotalDownPayment.TabIndex = 10;
            this.lblTotalDownPayment.Text = "Placeholder";
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(240, 327);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(72, 23);
            this.btnRefresh.TabIndex = 11;
            this.btnRefresh.TabStop = false;
            this.btnRefresh.Text = "Total Sum";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // grpType
            // 
            this.grpType.Controls.Add(this.rbRental);
            this.grpType.Controls.Add(this.rbRegular);
            this.grpType.Location = new System.Drawing.Point(153, 37);
            this.grpType.Name = "grpType";
            this.grpType.Size = new System.Drawing.Size(239, 43);
            this.grpType.TabIndex = 3;
            this.grpType.TabStop = false;
            // 
            // rbRental
            // 
            this.rbRental.AutoSize = true;
            this.rbRental.Location = new System.Drawing.Point(133, 19);
            this.rbRental.Name = "rbRental";
            this.rbRental.Size = new System.Drawing.Size(56, 17);
            this.rbRental.TabIndex = 1;
            this.rbRental.Text = "Rental";
            this.rbRental.UseVisualStyleBackColor = true;
            // 
            // rbRegular
            // 
            this.rbRegular.AutoSize = true;
            this.rbRegular.Checked = true;
            this.rbRegular.Location = new System.Drawing.Point(36, 19);
            this.rbRegular.Name = "rbRegular";
            this.rbRegular.Size = new System.Drawing.Size(70, 17);
            this.rbRegular.TabIndex = 0;
            this.rbRegular.TabStop = true;
            this.rbRegular.Text = "Purchase";
            this.rbRegular.UseVisualStyleBackColor = true;
            // 
            // frmNewCustomer2
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.grpType);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.lblTotalDownPayment);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgvDownPayment);
            this.Controls.Add(this.lblDownPayment);
            this.Controls.Add(this.lblTypeRental);
            this.Controls.Add(this.txtCashPrice);
            this.Controls.Add(this.lblCashPrice);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDownPayment)).EndInit();
            this.grpType.ResumeLayout(false);
            this.grpType.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCashPrice;
        private System.Windows.Forms.TextBox txtCashPrice;
        private System.Windows.Forms.Label lblTypeRental;
        private System.Windows.Forms.Label lblDownPayment;
        private System.Windows.Forms.DataGridView dgvDownPayment;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTotalDownPayment;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.GroupBox grpType;
        private System.Windows.Forms.RadioButton rbRental;
        private System.Windows.Forms.RadioButton rbRegular;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn DueDate;
    }
}