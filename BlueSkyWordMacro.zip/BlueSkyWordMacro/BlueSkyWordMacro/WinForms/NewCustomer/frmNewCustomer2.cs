﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    public partial class frmNewCustomer2 : Form
    {

#region Constructors
        public frmNewCustomer2()
        {
            InitializeComponent();
        }

        #endregion

#region Events
        private void btnBack_Click(object sender, EventArgs e)
        {

            if (SaveForm())
            {
                Form frm1 = new frmNewCustomer1();
                frm1.Show();
                this.Close();
            }
           
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (SaveForm())
            {
                Form frm3 = new frmNewCustomer4();
                frm3.Show();
                this.Close();
            }            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            GlobalMethods.ResetNewCustomer();
            this.Close();
        }

        private void frmNewCustomer2_Load(object sender, EventArgs e)
        {
            double totalDownPayment = 0;
            try
            {
                txtCashPrice.Text = GlobalVars.MyNewCustomer.CashPrice.ToString();
                
                if (GlobalVars.MyNewCustomer.TypeOwnership.ToLower().Equals("rental"))
                {
                    rbRental.Checked = true;
                }
                else
                {
                    rbRegular.Checked = true;
                }

                foreach(DownPayment dwnPmt in GlobalVars.MyNewCustomer.DownPayments)
                {
                    dgvDownPayment.Rows.Add(dwnPmt.DownPaymentAmount, dwnPmt.DownPaymentDate);
                    totalDownPayment += dwnPmt.DownPaymentAmount;
                }
                lblTotalDownPayment.Text = totalDownPayment.ToString("c");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            SaveForm();
            lblTotalDownPayment.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c");

            
        }

#endregion

#region Methods
        private bool SaveForm()
        {
            try
            {
                if (Convert.ToDouble(txtCashPrice.Text) > 0)
                {
                    GlobalVars.MyNewCustomer.CashPrice = Convert.ToDouble(txtCashPrice.Text);
                }else
                {
                    GlobalVars.MyNewCustomer.CashPrice = 0;
                }

                if(rbRegular.Checked)
                {
                    GlobalVars.MyNewCustomer.TypeOwnership = "Regular";
                }
                else
                {
                    GlobalVars.MyNewCustomer.TypeOwnership = "Rental";
                }

                GlobalVars.MyNewCustomer.DownPayments.Clear();

                foreach (DataGridViewRow dr in dgvDownPayment.Rows)
                {
                    DownPayment dwnPmt = new DownPayment();
                    if (!(dr.Cells["Amount"].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["Amount"].Value.ToString())))
                        {
                            if (GlobalMethods.IsDouble(dr.Cells["Amount"].Value.ToString()))
                            {
                                dwnPmt.DownPaymentAmount = Convert.ToDouble(dr.Cells["Amount"].Value.ToString());
                            }
                            else
                            {
                                MessageBox.Show("Down Payment Amount must be a number.");
                                return false;
                            }
                        }
                    }
                    if (!(dr.Cells[1].Value is null))
                    {
                        if (!(string.IsNullOrEmpty(dr.Cells["DueDate"].Value.ToString())))
                        {
                            if (GlobalMethods.IsValidDateTime(dr.Cells["DueDate"].Value.ToString()))
                            {
                                dwnPmt.DownPaymentDate = dr.Cells["DueDate"].Value.ToString();
                            }
                            else
                            {
                                MessageBox.Show("Down Payment Due Date must be a date or empty.");
                                return false;
                            }
                        }
                    }
                    if (dwnPmt.DownPaymentAmount > 0)
                    {
                        GlobalVars.MyNewCustomer.DownPayments.Add(dwnPmt);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
            return true;
        }

#endregion


    }
}
