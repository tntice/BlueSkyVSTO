﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer4));
            this.lblTaxesDue = new System.Windows.Forms.Label();
            this.dgvTaxesDue = new System.Windows.Forms.DataGridView();
            this.lblSewerTapFeeDue = new System.Windows.Forms.Label();
            this.dgvSewerTapFeeDue = new System.Windows.Forms.DataGridView();
            this.lblSewerSecurityDepositDue = new System.Windows.Forms.Label();
            this.dgvSewerSecurityDepositDue = new System.Windows.Forms.DataGridView();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.AmountDue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AmountPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.SewerTapFeeDueAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SewerTapFeePaidAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SewerTapFeeDueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SewerSecurityAmountDue = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SewerSecurityAmountPaid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WaterSecurityDepositDueDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaxesDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSewerTapFeeDue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSewerSecurityDepositDue)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTaxesDue
            // 
            this.lblTaxesDue.AutoSize = true;
            this.lblTaxesDue.Location = new System.Drawing.Point(13, 13);
            this.lblTaxesDue.Name = "lblTaxesDue";
            this.lblTaxesDue.Size = new System.Drawing.Size(59, 13);
            this.lblTaxesDue.TabIndex = 0;
            this.lblTaxesDue.Text = "Taxes Due";
            // 
            // dgvTaxesDue
            // 
            this.dgvTaxesDue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTaxesDue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AmountDue,
            this.AmountPaid,
            this.DueDate});
            this.dgvTaxesDue.Location = new System.Drawing.Point(166, 12);
            this.dgvTaxesDue.Name = "dgvTaxesDue";
            this.dgvTaxesDue.Size = new System.Drawing.Size(474, 95);
            this.dgvTaxesDue.TabIndex = 1;
            // 
            // lblSewerTapFeeDue
            // 
            this.lblSewerTapFeeDue.AutoSize = true;
            this.lblSewerTapFeeDue.Location = new System.Drawing.Point(13, 138);
            this.lblSewerTapFeeDue.Name = "lblSewerTapFeeDue";
            this.lblSewerTapFeeDue.Size = new System.Drawing.Size(137, 13);
            this.lblSewerTapFeeDue.TabIndex = 2;
            this.lblSewerTapFeeDue.Text = "Water/Sewer Tap Fee Due";
            // 
            // dgvSewerTapFeeDue
            // 
            this.dgvSewerTapFeeDue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSewerTapFeeDue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SewerTapFeeDueAmount,
            this.SewerTapFeePaidAmount,
            this.SewerTapFeeDueDate});
            this.dgvSewerTapFeeDue.Location = new System.Drawing.Point(166, 138);
            this.dgvSewerTapFeeDue.Name = "dgvSewerTapFeeDue";
            this.dgvSewerTapFeeDue.Size = new System.Drawing.Size(474, 95);
            this.dgvSewerTapFeeDue.TabIndex = 3;
            // 
            // lblSewerSecurityDepositDue
            // 
            this.lblSewerSecurityDepositDue.AutoSize = true;
            this.lblSewerSecurityDepositDue.Location = new System.Drawing.Point(13, 262);
            this.lblSewerSecurityDepositDue.Name = "lblSewerSecurityDepositDue";
            this.lblSewerSecurityDepositDue.Size = new System.Drawing.Size(115, 13);
            this.lblSewerSecurityDepositDue.TabIndex = 4;
            this.lblSewerSecurityDepositDue.Text = "Water/Sewer Security ";
            // 
            // dgvSewerSecurityDepositDue
            // 
            this.dgvSewerSecurityDepositDue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSewerSecurityDepositDue.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SewerSecurityAmountDue,
            this.SewerSecurityAmountPaid,
            this.WaterSecurityDepositDueDate});
            this.dgvSewerSecurityDepositDue.Location = new System.Drawing.Point(166, 262);
            this.dgvSewerSecurityDepositDue.Name = "dgvSewerSecurityDepositDue";
            this.dgvSewerSecurityDepositDue.Size = new System.Drawing.Size(474, 95);
            this.dgvSewerSecurityDepositDue.TabIndex = 5;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(410, 375);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(84, 28);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 7;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // AmountDue
            // 
            this.AmountDue.HeaderText = "Amount Due";
            this.AmountDue.Name = "AmountDue";
            this.AmountDue.Width = 150;
            // 
            // AmountPaid
            // 
            this.AmountPaid.HeaderText = "Amount Paid";
            this.AmountPaid.Name = "AmountPaid";
            this.AmountPaid.Width = 150;
            // 
            // DueDate
            // 
            this.DueDate.HeaderText = "Due Date";
            this.DueDate.Name = "DueDate";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Deposit Due";
            // 
            // SewerTapFeeDueAmount
            // 
            this.SewerTapFeeDueAmount.HeaderText = "Amount Due";
            this.SewerTapFeeDueAmount.Name = "SewerTapFeeDueAmount";
            this.SewerTapFeeDueAmount.Width = 150;
            // 
            // SewerTapFeePaidAmount
            // 
            this.SewerTapFeePaidAmount.HeaderText = "Amount Paid";
            this.SewerTapFeePaidAmount.Name = "SewerTapFeePaidAmount";
            this.SewerTapFeePaidAmount.Width = 150;
            // 
            // SewerTapFeeDueDate
            // 
            this.SewerTapFeeDueDate.HeaderText = "Due Date";
            this.SewerTapFeeDueDate.Name = "SewerTapFeeDueDate";
            // 
            // SewerSecurityAmountDue
            // 
            this.SewerSecurityAmountDue.HeaderText = "Amount Due";
            this.SewerSecurityAmountDue.Name = "SewerSecurityAmountDue";
            this.SewerSecurityAmountDue.Width = 150;
            // 
            // SewerSecurityAmountPaid
            // 
            this.SewerSecurityAmountPaid.HeaderText = "Amount Paid";
            this.SewerSecurityAmountPaid.Name = "SewerSecurityAmountPaid";
            this.SewerSecurityAmountPaid.Width = 150;
            // 
            // WaterSecurityDepositDueDate
            // 
            this.WaterSecurityDepositDueDate.HeaderText = "Due Date";
            this.WaterSecurityDepositDueDate.Name = "WaterSecurityDepositDueDate";
            // 
            // frmNewCustomer4
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.dgvSewerSecurityDepositDue);
            this.Controls.Add(this.lblSewerSecurityDepositDue);
            this.Controls.Add(this.dgvSewerTapFeeDue);
            this.Controls.Add(this.lblSewerTapFeeDue);
            this.Controls.Add(this.dgvTaxesDue);
            this.Controls.Add(this.lblTaxesDue);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTaxesDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSewerTapFeeDue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSewerSecurityDepositDue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTaxesDue;
        private System.Windows.Forms.DataGridView dgvTaxesDue;
        private System.Windows.Forms.Label lblSewerTapFeeDue;
        private System.Windows.Forms.DataGridView dgvSewerTapFeeDue;
        private System.Windows.Forms.Label lblSewerSecurityDepositDue;
        private System.Windows.Forms.DataGridView dgvSewerSecurityDepositDue;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DataGridViewTextBoxColumn AmountDue;
        private System.Windows.Forms.DataGridViewTextBoxColumn AmountPaid;
        private System.Windows.Forms.DataGridViewTextBoxColumn DueDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SewerTapFeeDueAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SewerTapFeePaidAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn SewerTapFeeDueDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn SewerSecurityAmountDue;
        private System.Windows.Forms.DataGridViewTextBoxColumn SewerSecurityAmountPaid;
        private System.Windows.Forms.DataGridViewTextBoxColumn WaterSecurityDepositDueDate;
    }
}