﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer6));
            this.lblAssessmentNumber = new System.Windows.Forms.Label();
            this.txtAssessmentNumber = new System.Windows.Forms.TextBox();
            this.lblPrincipalPerMonth = new System.Windows.Forms.Label();
            this.txtPrincipalPerMonth = new System.Windows.Forms.TextBox();
            this.lblInterestPerMonth = new System.Windows.Forms.Label();
            this.txtInterestPerMonth = new System.Windows.Forms.TextBox();
            this.lblTotalActualPrice = new System.Windows.Forms.Label();
            this.txtTotalActualPrice = new System.Windows.Forms.TextBox();
            this.lblSellerCost = new System.Windows.Forms.Label();
            this.txtSellersCost = new System.Windows.Forms.TextBox();
            this.lblSellersPurchaseDate = new System.Windows.Forms.Label();
            this.txtSellersPurchaseDate = new System.Windows.Forms.TextBox();
            this.lblSellersDBRefreence = new System.Windows.Forms.Label();
            this.txtSellersDBReference = new System.Windows.Forms.TextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnCalculateSellersProfit = new System.Windows.Forms.Button();
            this.txtSellersProfit = new System.Windows.Forms.TextBox();
            this.lblSellersProfit = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAssessmentNumber
            // 
            this.lblAssessmentNumber.AutoSize = true;
            this.lblAssessmentNumber.Location = new System.Drawing.Point(13, 13);
            this.lblAssessmentNumber.Name = "lblAssessmentNumber";
            this.lblAssessmentNumber.Size = new System.Drawing.Size(103, 13);
            this.lblAssessmentNumber.TabIndex = 0;
            this.lblAssessmentNumber.Text = "Assessment Number";
            // 
            // txtAssessmentNumber
            // 
            this.txtAssessmentNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAssessmentNumber.Location = new System.Drawing.Point(136, 10);
            this.txtAssessmentNumber.Name = "txtAssessmentNumber";
            this.txtAssessmentNumber.Size = new System.Drawing.Size(376, 20);
            this.txtAssessmentNumber.TabIndex = 1;
            // 
            // lblPrincipalPerMonth
            // 
            this.lblPrincipalPerMonth.AutoSize = true;
            this.lblPrincipalPerMonth.Location = new System.Drawing.Point(13, 40);
            this.lblPrincipalPerMonth.Name = "lblPrincipalPerMonth";
            this.lblPrincipalPerMonth.Size = new System.Drawing.Size(99, 13);
            this.lblPrincipalPerMonth.TabIndex = 2;
            this.lblPrincipalPerMonth.Text = "Principal Per Month";
            // 
            // txtPrincipalPerMonth
            // 
            this.txtPrincipalPerMonth.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPrincipalPerMonth.Location = new System.Drawing.Point(136, 37);
            this.txtPrincipalPerMonth.Name = "txtPrincipalPerMonth";
            this.txtPrincipalPerMonth.Size = new System.Drawing.Size(376, 20);
            this.txtPrincipalPerMonth.TabIndex = 3;
            // 
            // lblInterestPerMonth
            // 
            this.lblInterestPerMonth.AutoSize = true;
            this.lblInterestPerMonth.Location = new System.Drawing.Point(13, 67);
            this.lblInterestPerMonth.Name = "lblInterestPerMonth";
            this.lblInterestPerMonth.Size = new System.Drawing.Size(94, 13);
            this.lblInterestPerMonth.TabIndex = 4;
            this.lblInterestPerMonth.Text = "Interest Per Month";
            // 
            // txtInterestPerMonth
            // 
            this.txtInterestPerMonth.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInterestPerMonth.Location = new System.Drawing.Point(136, 64);
            this.txtInterestPerMonth.Name = "txtInterestPerMonth";
            this.txtInterestPerMonth.Size = new System.Drawing.Size(376, 20);
            this.txtInterestPerMonth.TabIndex = 5;
            // 
            // lblTotalActualPrice
            // 
            this.lblTotalActualPrice.AutoSize = true;
            this.lblTotalActualPrice.Location = new System.Drawing.Point(13, 94);
            this.lblTotalActualPrice.Name = "lblTotalActualPrice";
            this.lblTotalActualPrice.Size = new System.Drawing.Size(87, 13);
            this.lblTotalActualPrice.TabIndex = 6;
            this.lblTotalActualPrice.Text = "Total Sales Price";
            // 
            // txtTotalActualPrice
            // 
            this.txtTotalActualPrice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTotalActualPrice.Location = new System.Drawing.Point(136, 91);
            this.txtTotalActualPrice.Name = "txtTotalActualPrice";
            this.txtTotalActualPrice.Size = new System.Drawing.Size(376, 20);
            this.txtTotalActualPrice.TabIndex = 7;
            // 
            // lblSellerCost
            // 
            this.lblSellerCost.AutoSize = true;
            this.lblSellerCost.Location = new System.Drawing.Point(13, 154);
            this.lblSellerCost.Name = "lblSellerCost";
            this.lblSellerCost.Size = new System.Drawing.Size(64, 13);
            this.lblSellerCost.TabIndex = 12;
            this.lblSellerCost.Text = "Seller\'s Cost";
            // 
            // txtSellersCost
            // 
            this.txtSellersCost.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSellersCost.Location = new System.Drawing.Point(136, 151);
            this.txtSellersCost.Name = "txtSellersCost";
            this.txtSellersCost.Size = new System.Drawing.Size(376, 20);
            this.txtSellersCost.TabIndex = 13;
            // 
            // lblSellersPurchaseDate
            // 
            this.lblSellersPurchaseDate.AutoSize = true;
            this.lblSellersPurchaseDate.Location = new System.Drawing.Point(13, 181);
            this.lblSellersPurchaseDate.Name = "lblSellersPurchaseDate";
            this.lblSellersPurchaseDate.Size = new System.Drawing.Size(114, 13);
            this.lblSellersPurchaseDate.TabIndex = 14;
            this.lblSellersPurchaseDate.Text = "Seller\'s Purchase Date";
            // 
            // txtSellersPurchaseDate
            // 
            this.txtSellersPurchaseDate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSellersPurchaseDate.Location = new System.Drawing.Point(136, 178);
            this.txtSellersPurchaseDate.Name = "txtSellersPurchaseDate";
            this.txtSellersPurchaseDate.Size = new System.Drawing.Size(376, 20);
            this.txtSellersPurchaseDate.TabIndex = 15;
            // 
            // lblSellersDBRefreence
            // 
            this.lblSellersDBRefreence.AutoSize = true;
            this.lblSellersDBRefreence.Location = new System.Drawing.Point(13, 209);
            this.lblSellersDBRefreence.Name = "lblSellersDBRefreence";
            this.lblSellersDBRefreence.Size = new System.Drawing.Size(111, 13);
            this.lblSellersDBRefreence.TabIndex = 16;
            this.lblSellersDBRefreence.Text = "Seller\'s DB Reference";
            // 
            // txtSellersDBReference
            // 
            this.txtSellersDBReference.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSellersDBReference.Location = new System.Drawing.Point(136, 205);
            this.txtSellersDBReference.Name = "txtSellersDBReference";
            this.txtSellersDBReference.Size = new System.Drawing.Size(376, 20);
            this.txtSellersDBReference.TabIndex = 17;
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(410, 375);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(84, 28);
            this.btnBack.TabIndex = 21;
            this.btnBack.Text = "&Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 22;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 23;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Incl Interest for Full";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 13);
            this.label2.TabIndex = 22;
            this.label2.Text = "Finance Term + Down Payment";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(518, 89);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(75, 23);
            this.btnCalculate.TabIndex = 23;
            this.btnCalculate.TabStop = false;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnCalculateSellersProfit
            // 
            this.btnCalculateSellersProfit.Location = new System.Drawing.Point(518, 228);
            this.btnCalculateSellersProfit.Name = "btnCalculateSellersProfit";
            this.btnCalculateSellersProfit.Size = new System.Drawing.Size(75, 23);
            this.btnCalculateSellersProfit.TabIndex = 20;
            this.btnCalculateSellersProfit.TabStop = false;
            this.btnCalculateSellersProfit.Text = "Calculate";
            this.btnCalculateSellersProfit.UseVisualStyleBackColor = true;
            this.btnCalculateSellersProfit.Click += new System.EventHandler(this.btnCalculateSellersProfit_Click);
            // 
            // txtSellersProfit
            // 
            this.txtSellersProfit.Location = new System.Drawing.Point(136, 231);
            this.txtSellersProfit.Name = "txtSellersProfit";
            this.txtSellersProfit.Size = new System.Drawing.Size(376, 20);
            this.txtSellersProfit.TabIndex = 19;
            // 
            // lblSellersProfit
            // 
            this.lblSellersProfit.AutoSize = true;
            this.lblSellersProfit.Location = new System.Drawing.Point(13, 234);
            this.lblSellersProfit.Name = "lblSellersProfit";
            this.lblSellersProfit.Size = new System.Drawing.Size(67, 13);
            this.lblSellersProfit.TabIndex = 18;
            this.lblSellersProfit.Text = "Seller\'s Profit";
            // 
            // frmNewCustomer6
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.btnCalculateSellersProfit);
            this.Controls.Add(this.txtSellersProfit);
            this.Controls.Add(this.lblSellersProfit);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.txtSellersDBReference);
            this.Controls.Add(this.lblSellersDBRefreence);
            this.Controls.Add(this.txtSellersPurchaseDate);
            this.Controls.Add(this.lblSellersPurchaseDate);
            this.Controls.Add(this.txtSellersCost);
            this.Controls.Add(this.lblSellerCost);
            this.Controls.Add(this.txtTotalActualPrice);
            this.Controls.Add(this.lblTotalActualPrice);
            this.Controls.Add(this.txtInterestPerMonth);
            this.Controls.Add(this.lblInterestPerMonth);
            this.Controls.Add(this.txtPrincipalPerMonth);
            this.Controls.Add(this.lblPrincipalPerMonth);
            this.Controls.Add(this.txtAssessmentNumber);
            this.Controls.Add(this.lblAssessmentNumber);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer6";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer6_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAssessmentNumber;
        private System.Windows.Forms.TextBox txtAssessmentNumber;
        private System.Windows.Forms.Label lblPrincipalPerMonth;
        private System.Windows.Forms.TextBox txtPrincipalPerMonth;
        private System.Windows.Forms.Label lblInterestPerMonth;
        private System.Windows.Forms.TextBox txtInterestPerMonth;
        private System.Windows.Forms.Label lblTotalActualPrice;
        private System.Windows.Forms.TextBox txtTotalActualPrice;
        private System.Windows.Forms.Label lblSellerCost;
        private System.Windows.Forms.TextBox txtSellersCost;
        private System.Windows.Forms.Label lblSellersPurchaseDate;
        private System.Windows.Forms.TextBox txtSellersPurchaseDate;
        private System.Windows.Forms.Label lblSellersDBRefreence;
        private System.Windows.Forms.TextBox txtSellersDBReference;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnCalculateSellersProfit;
        private System.Windows.Forms.TextBox txtSellersProfit;
        private System.Windows.Forms.Label lblSellersProfit;
    }
}