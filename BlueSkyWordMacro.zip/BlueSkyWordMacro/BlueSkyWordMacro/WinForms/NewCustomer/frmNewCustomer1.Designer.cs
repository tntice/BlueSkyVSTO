﻿namespace BlueSkyWordMacro.WinForms.NewCustomer
{
    partial class frmNewCustomer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewCustomer1));
            this.btnNext = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnChangeMowreyNumber = new System.Windows.Forms.Button();
            this.lblDate = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblTownship = new System.Windows.Forms.Label();
            this.txtTownship = new System.Windows.Forms.TextBox();
            this.lblCounty = new System.Windows.Forms.Label();
            this.lblSeller = new System.Windows.Forms.Label();
            this.txtSeller = new System.Windows.Forms.TextBox();
            this.lblBuyer = new System.Windows.Forms.Label();
            this.txtBuyer = new System.Windows.Forms.TextBox();
            this.lblStreetAddress1 = new System.Windows.Forms.Label();
            this.txtStreetAddress1 = new System.Windows.Forms.TextBox();
            this.lblStreetAddress2 = new System.Windows.Forms.Label();
            this.txtStreetAddress2 = new System.Windows.Forms.TextBox();
            this.lblCityStateZip = new System.Windows.Forms.Label();
            this.txtCityStateZip = new System.Windows.Forms.TextBox();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.TextBox();
            this.cboCounty = new System.Windows.Forms.ComboBox();
            this.btnTestData = new System.Windows.Forms.Button();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtMowreyNumber = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(510, 375);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(84, 28);
            this.btnNext.TabIndex = 25;
            this.btnNext.Text = "&Next";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(610, 375);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 28);
            this.btnCancel.TabIndex = 26;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mowrey Number";
            // 
            // btnChangeMowreyNumber
            // 
            this.btnChangeMowreyNumber.Location = new System.Drawing.Point(366, 28);
            this.btnChangeMowreyNumber.Name = "btnChangeMowreyNumber";
            this.btnChangeMowreyNumber.Size = new System.Drawing.Size(62, 25);
            this.btnChangeMowreyNumber.TabIndex = 2;
            this.btnChangeMowreyNumber.TabStop = false;
            this.btnChangeMowreyNumber.Text = "Change";
            this.btnChangeMowreyNumber.UseVisualStyleBackColor = true;
            this.btnChangeMowreyNumber.Visible = false;
            this.btnChangeMowreyNumber.Click += new System.EventHandler(this.btnChangeMowreyNumber_Click);
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(27, 60);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(30, 13);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "Date";
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(138, 57);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(186, 20);
            this.txtDate.TabIndex = 4;
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(27, 86);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(60, 13);
            this.lblDescription.TabIndex = 5;
            this.lblDescription.Text = "Description";
            // 
            // txtDescription
            // 
            this.txtDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDescription.Location = new System.Drawing.Point(138, 83);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescription.Size = new System.Drawing.Size(557, 46);
            this.txtDescription.TabIndex = 6;
            // 
            // lblTownship
            // 
            this.lblTownship.AutoSize = true;
            this.lblTownship.Location = new System.Drawing.Point(27, 138);
            this.lblTownship.Name = "lblTownship";
            this.lblTownship.Size = new System.Drawing.Size(98, 13);
            this.lblTownship.TabIndex = 7;
            this.lblTownship.Text = "Township/Borough";
            // 
            // txtTownship
            // 
            this.txtTownship.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTownship.Location = new System.Drawing.Point(138, 135);
            this.txtTownship.Name = "txtTownship";
            this.txtTownship.Size = new System.Drawing.Size(557, 20);
            this.txtTownship.TabIndex = 8;
            // 
            // lblCounty
            // 
            this.lblCounty.AutoSize = true;
            this.lblCounty.Location = new System.Drawing.Point(27, 164);
            this.lblCounty.Name = "lblCounty";
            this.lblCounty.Size = new System.Drawing.Size(40, 13);
            this.lblCounty.TabIndex = 9;
            this.lblCounty.Text = "County";
            // 
            // lblSeller
            // 
            this.lblSeller.AutoSize = true;
            this.lblSeller.Location = new System.Drawing.Point(27, 190);
            this.lblSeller.Name = "lblSeller";
            this.lblSeller.Size = new System.Drawing.Size(70, 13);
            this.lblSeller.TabIndex = 11;
            this.lblSeller.Text = "Seller/Leasor";
            // 
            // txtSeller
            // 
            this.txtSeller.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSeller.Location = new System.Drawing.Point(138, 187);
            this.txtSeller.Name = "txtSeller";
            this.txtSeller.Size = new System.Drawing.Size(557, 20);
            this.txtSeller.TabIndex = 12;
            // 
            // lblBuyer
            // 
            this.lblBuyer.AutoSize = true;
            this.lblBuyer.Location = new System.Drawing.Point(27, 216);
            this.lblBuyer.Name = "lblBuyer";
            this.lblBuyer.Size = new System.Drawing.Size(74, 13);
            this.lblBuyer.TabIndex = 13;
            this.lblBuyer.Text = "Buyer/Leasee";
            // 
            // txtBuyer
            // 
            this.txtBuyer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBuyer.Location = new System.Drawing.Point(138, 213);
            this.txtBuyer.Name = "txtBuyer";
            this.txtBuyer.Size = new System.Drawing.Size(557, 20);
            this.txtBuyer.TabIndex = 14;
            // 
            // lblStreetAddress1
            // 
            this.lblStreetAddress1.AutoSize = true;
            this.lblStreetAddress1.Location = new System.Drawing.Point(27, 246);
            this.lblStreetAddress1.Name = "lblStreetAddress1";
            this.lblStreetAddress1.Size = new System.Drawing.Size(85, 13);
            this.lblStreetAddress1.TabIndex = 15;
            this.lblStreetAddress1.Text = "Street Address 1";
            // 
            // txtStreetAddress1
            // 
            this.txtStreetAddress1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStreetAddress1.Location = new System.Drawing.Point(138, 239);
            this.txtStreetAddress1.Name = "txtStreetAddress1";
            this.txtStreetAddress1.Size = new System.Drawing.Size(557, 20);
            this.txtStreetAddress1.TabIndex = 16;
            // 
            // lblStreetAddress2
            // 
            this.lblStreetAddress2.AutoSize = true;
            this.lblStreetAddress2.Location = new System.Drawing.Point(27, 268);
            this.lblStreetAddress2.Name = "lblStreetAddress2";
            this.lblStreetAddress2.Size = new System.Drawing.Size(85, 13);
            this.lblStreetAddress2.TabIndex = 17;
            this.lblStreetAddress2.Text = "Street Address 2";
            // 
            // txtStreetAddress2
            // 
            this.txtStreetAddress2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStreetAddress2.Location = new System.Drawing.Point(138, 265);
            this.txtStreetAddress2.Name = "txtStreetAddress2";
            this.txtStreetAddress2.Size = new System.Drawing.Size(557, 20);
            this.txtStreetAddress2.TabIndex = 18;
            // 
            // lblCityStateZip
            // 
            this.lblCityStateZip.AutoSize = true;
            this.lblCityStateZip.Location = new System.Drawing.Point(27, 294);
            this.lblCityStateZip.Name = "lblCityStateZip";
            this.lblCityStateZip.Size = new System.Drawing.Size(76, 13);
            this.lblCityStateZip.TabIndex = 19;
            this.lblCityStateZip.Text = "City, State, Zip";
            // 
            // txtCityStateZip
            // 
            this.txtCityStateZip.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCityStateZip.Location = new System.Drawing.Point(138, 291);
            this.txtCityStateZip.Name = "txtCityStateZip";
            this.txtCityStateZip.Size = new System.Drawing.Size(557, 20);
            this.txtCityStateZip.TabIndex = 20;
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(27, 320);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(78, 13);
            this.lblPhoneNumber.TabIndex = 21;
            this.lblPhoneNumber.Text = "Phone Number";
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPhoneNumber.Location = new System.Drawing.Point(138, 317);
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(557, 20);
            this.txtPhoneNumber.TabIndex = 22;
            // 
            // cboCounty
            // 
            this.cboCounty.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboCounty.FormattingEnabled = true;
            this.cboCounty.Location = new System.Drawing.Point(138, 160);
            this.cboCounty.Name = "cboCounty";
            this.cboCounty.Size = new System.Drawing.Size(557, 21);
            this.cboCounty.TabIndex = 10;
            // 
            // btnTestData
            // 
            this.btnTestData.Location = new System.Drawing.Point(30, 371);
            this.btnTestData.Name = "btnTestData";
            this.btnTestData.Size = new System.Drawing.Size(84, 28);
            this.btnTestData.TabIndex = 27;
            this.btnTestData.TabStop = false;
            this.btnTestData.Text = "Test Data";
            this.btnTestData.UseVisualStyleBackColor = true;
            this.btnTestData.Visible = false;
            this.btnTestData.Click += new System.EventHandler(this.btnTestData_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(27, 347);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 23;
            this.lblEmail.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail.Location = new System.Drawing.Point(138, 344);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(556, 20);
            this.txtEmail.TabIndex = 24;
            // 
            // txtMowreyNumber
            // 
            this.txtMowreyNumber.Location = new System.Drawing.Point(138, 31);
            this.txtMowreyNumber.Name = "txtMowreyNumber";
            this.txtMowreyNumber.Size = new System.Drawing.Size(186, 20);
            this.txtMowreyNumber.TabIndex = 1;
            // 
            // frmNewCustomer1
            // 
            this.AcceptButton = this.btnNext;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(724, 411);
            this.Controls.Add(this.txtMowreyNumber);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.btnTestData);
            this.Controls.Add(this.cboCounty);
            this.Controls.Add(this.txtPhoneNumber);
            this.Controls.Add(this.lblPhoneNumber);
            this.Controls.Add(this.txtCityStateZip);
            this.Controls.Add(this.lblCityStateZip);
            this.Controls.Add(this.txtStreetAddress2);
            this.Controls.Add(this.lblStreetAddress2);
            this.Controls.Add(this.txtStreetAddress1);
            this.Controls.Add(this.lblStreetAddress1);
            this.Controls.Add(this.txtBuyer);
            this.Controls.Add(this.lblBuyer);
            this.Controls.Add(this.txtSeller);
            this.Controls.Add(this.lblSeller);
            this.Controls.Add(this.lblCounty);
            this.Controls.Add(this.txtTownship);
            this.Controls.Add(this.lblTownship);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.txtDate);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.btnChangeMowreyNumber);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmNewCustomer1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Customer";
            this.Load += new System.EventHandler(this.frmNewCustomer1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnChangeMowreyNumber;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblTownship;
        private System.Windows.Forms.TextBox txtTownship;
        private System.Windows.Forms.Label lblCounty;
        private System.Windows.Forms.Label lblSeller;
        private System.Windows.Forms.TextBox txtSeller;
        private System.Windows.Forms.Label lblBuyer;
        private System.Windows.Forms.TextBox txtBuyer;
        private System.Windows.Forms.Label lblStreetAddress1;
        private System.Windows.Forms.TextBox txtStreetAddress1;
        private System.Windows.Forms.Label lblStreetAddress2;
        private System.Windows.Forms.TextBox txtStreetAddress2;
        private System.Windows.Forms.Label lblCityStateZip;
        private System.Windows.Forms.TextBox txtCityStateZip;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtPhoneNumber;
        private System.Windows.Forms.ComboBox cboCounty;
        private System.Windows.Forms.Button btnTestData;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtMowreyNumber;
    }
}