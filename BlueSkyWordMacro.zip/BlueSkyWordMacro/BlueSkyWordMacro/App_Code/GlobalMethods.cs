﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace BlueSkyWordMacro
{
    public static class GlobalMethods
    {
        public static void SaveMowreyNumber()
        {

            Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            configuration.AppSettings.Settings["MowreyNumber"].Value = (GlobalVars.MowreyNumber + 1).ToString();
            configuration.Save();
            ConfigurationManager.RefreshSection("appSettings");
        }

        public static bool IsValidDateTime(string strDate)
        {
            bool returnValue = true;
            try
            {
                DateTime temp = Convert.ToDateTime(strDate);
                if ((temp == DateTime.MinValue) || (temp == DateTime.MaxValue))
                {
                    returnValue = false;
                }
            }
            catch
            {
                returnValue = false;
            }
            return returnValue;
        }

        public static bool IsDouble(string strNumber)
        {
            bool blnResult = true;
            try
            {
                double x;
                blnResult = double.TryParse(strNumber, out x);
            }
            catch
            {
                blnResult = false;
            }
            return blnResult;
        }

        public static void ResetNewCustomer()
        {
            GlobalVars.MyNewCustomer.SellDate = DateTime.Now;
            GlobalVars.MyNewCustomer.Description = string.Empty;
            GlobalVars.MyNewCustomer.TownshipBorough = string.Empty;
            GlobalVars.MyNewCustomer.County = string.Empty;
            GlobalVars.MyNewCustomer.Seller = string.Empty;
            GlobalVars.MyNewCustomer.Buyer = string.Empty;
            GlobalVars.MyNewCustomer.Address1 = string.Empty;
            GlobalVars.MyNewCustomer.Address2 = string.Empty;
            GlobalVars.MyNewCustomer.CityStateZip = string.Empty;
            GlobalVars.MyNewCustomer.PhoneNumber = string.Empty;
            GlobalVars.MyNewCustomer.Email = string.Empty;
            GlobalVars.MyNewCustomer.CashPrice = 0;
            GlobalVars.MyNewCustomer.TypeOwnership = string.Empty;
            GlobalVars.MyNewCustomer.DownPayments.Clear();
            GlobalVars.MyNewCustomer.FinanceAmount = 0;
            GlobalVars.MyNewCustomer.TermYears = 0;
            GlobalVars.MyNewCustomer.InterestRate = 0.12;
            GlobalVars.MyNewCustomer.PaymentAmount = 0;
            GlobalVars.MyNewCustomer.FirstPaymentDueDate = string.Empty;
            GlobalVars.MyNewCustomer.LastPaymentDueDate = string.Empty;
            GlobalVars.MyNewCustomer.TotalNumPayments = 0;
            GlobalVars.MyNewCustomer.LateFeeAmount = 0;
            GlobalVars.MyNewCustomer.ClericalFees.Clear();
            GlobalVars.MyNewCustomer.TaxesDues.Clear();
            GlobalVars.MyNewCustomer.InsuranceDues.Clear();
            GlobalVars.MyNewCustomer.SewerTapFeeDues.Clear();
            GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues.Clear();
            GlobalVars.MyNewCustomer.OtherDues.Clear();
            GlobalVars.MyNewCustomer.AssessmentNumber = string.Empty;
            GlobalVars.MyNewCustomer.PrincipalPerMonth = 0;
            GlobalVars.MyNewCustomer.InterestPerMonth = 0;
            GlobalVars.MyNewCustomer.TotalActualPrice = 0;
            GlobalVars.MyNewCustomer.SellersCost = 0;
            GlobalVars.MyNewCustomer.SellersPurchaseDate = string.Empty;
            GlobalVars.MyNewCustomer.SellersDBReference = string.Empty;
            
        }
        
        public static void PopulateTestData()
        {

            GlobalVars.MyNewCustomer.MowreyNumber = "2014";
            GlobalVars.MyNewCustomer.SellDate = Convert.ToDateTime("3/16/2017");
            GlobalVars.MyNewCustomer.Description = "House & Approx. 52' x 209' Lot (301 Quarry Ave.)";
            GlobalVars.MyNewCustomer.TownshipBorough = "DuBois City 1st Ward";
            GlobalVars.MyNewCustomer.County = "Clearfield";
            GlobalVars.MyNewCustomer.Seller = "Blue Sky Real Estate LP";
            GlobalVars.MyNewCustomer.Buyer = "Black, Tyler J.";
            GlobalVars.MyNewCustomer.Address1 = "301 Quarry Avenue" ;
            GlobalVars.MyNewCustomer.Address2 = string.Empty;
            GlobalVars.MyNewCustomer.CityStateZip = "DuBois, PA 15801";
            GlobalVars.MyNewCustomer.PhoneNumber = "603-1545 (Tyler Cell) 590-8577 (Girlfriend Christina) 590-8222 (Test)";
            GlobalVars.MyNewCustomer.Email = "tylerjamesblack192@gmail.com";
            GlobalVars.MyNewCustomer.CashPrice = 30000.00;
            GlobalVars.MyNewCustomer.TypeOwnership = "Regular";
            GlobalVars.MyNewCustomer.DownPayments.Clear();
            DownPayment dwnpmt = new DownPayment();
            dwnpmt.DownPaymentAmount = 4000;
            dwnpmt.DownPaymentDate = "3/16/2017";
            GlobalVars.MyNewCustomer.DownPayments.Add(dwnpmt);
            GlobalVars.MyNewCustomer.FinanceAmount = 28726;
            GlobalVars.MyNewCustomer.TermYears = 15;
            GlobalVars.MyNewCustomer.InterestRate = 0.12;
            GlobalVars.MyNewCustomer.PaymentAmount = 344.72;
            GlobalVars.MyNewCustomer.FirstPaymentDueDate = "4/15/2017";
            GlobalVars.MyNewCustomer.LastPaymentDueDate = "3/15/2032";
            GlobalVars.MyNewCustomer.TotalNumPayments = 180;
            GlobalVars.MyNewCustomer.LateFeeAmount = 60;
            GlobalVars.MyNewCustomer.ClericalFees.Clear();
            ClericalFee cFee = new ClericalFee();
            cFee.ClericalFeeDueAmount = 800;
            cFee.ClericalFeePaidAmount = 400;
            GlobalVars.MyNewCustomer.ClericalFees.Add(cFee);
            GlobalVars.MyNewCustomer.TaxesDues.Clear();
            TaxesDue tDue = new TaxesDue();
            tDue.TaxesDueAmount = 726;
            tDue.TaxesPaidAmount = 726;
            GlobalVars.MyNewCustomer.TaxesDues.Add(tDue);
            GlobalVars.MyNewCustomer.InsuranceDues.Clear();
            GlobalVars.MyNewCustomer.SewerTapFeeDues.Clear();
            SewerTapFeeDue sTapFee = new SewerTapFeeDue();
            sTapFee.SewerTapFeeDueAmount = 60;
            GlobalVars.MyNewCustomer.SewerTapFeeDues.Add(sTapFee);
            GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues.Clear();
            SewerSecurityDepositDue ssDepositDue = new SewerSecurityDepositDue();
            ssDepositDue.SewerSecurityDepositDueAmount = 100;
            ssDepositDue.SewerSecurityDepositPaidAmount = 10;
            GlobalVars.MyNewCustomer.SewerSecurityDepositFeeDues.Add(ssDepositDue);
            GlobalVars.MyNewCustomer.OtherDues.Clear();
            OtherDue oDue1 = new OtherDue();
            oDue1.OtherDueAmount = 400;
            oDue1.OtherPaidAmount = 0;
            oDue1.Description = "Road Fee";
            OtherDue oDue2 = new OtherDue();
            oDue2.OtherDueAmount = 100;
            oDue2.OtherPaidAmount = 100;
            oDue2.Description = "Misc";
            GlobalVars.MyNewCustomer.OtherDues.Add(oDue1);
            GlobalVars.MyNewCustomer.OtherDues.Add(oDue2);
            GlobalVars.MyNewCustomer.AssessmentNumber = "020-000-06386";
            GlobalVars.MyNewCustomer.PrincipalPerMonth = 159.59;
            GlobalVars.MyNewCustomer.InterestPerMonth = 185.13;
            GlobalVars.MyNewCustomer.TotalActualPrice = 30950;
            GlobalVars.MyNewCustomer.SellersCost = 4492.15;
            GlobalVars.MyNewCustomer.SellersPurchaseDate = "9/16/2016";
            GlobalVars.MyNewCustomer.SellersDBReference = "2597";
            GlobalVars.MyNewCustomer.SellersProfit = 26457.85;

        }

        public static string LineBreakPhoneNumber(string phoneNumber)
        {
            string thisPhone = string.Empty;
            try
            {
                thisPhone = phoneNumber.Replace(")", ")" + Environment.NewLine);
                if (thisPhone.Length >= 2)
                {
                    string strLast = thisPhone.Substring(thisPhone.Length - 2);
                    if (strLast == "\r\n")
                    {
                        thisPhone = thisPhone.Substring(0, thisPhone.Length - 2);
                    }
                }
            }
            catch
            {
                thisPhone = string.Empty;
            }
            return thisPhone;
        }
    }
}
