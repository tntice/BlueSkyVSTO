﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class SewerSecurityDepositDue
    {
        private double _sewerSecurityDepositDueAmount = 0;
        private string _dueDate = string.Empty;
        private double _sewerSecurityDepositPaidAmount = 0;

        public double SewerSecurityDepositDueAmount { get => _sewerSecurityDepositDueAmount; set => _sewerSecurityDepositDueAmount = value; }
        public string DueDate { get => _dueDate; set => _dueDate = value; }
        public double SewerSecurityDepositPaidAmount { get => _sewerSecurityDepositPaidAmount; set => _sewerSecurityDepositPaidAmount = value; }
    }
}
