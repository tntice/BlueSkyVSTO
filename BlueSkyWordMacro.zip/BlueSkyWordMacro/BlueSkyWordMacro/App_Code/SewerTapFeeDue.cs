﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class SewerTapFeeDue
    {
        private double _sewerTapFeeDueAmount = 0;
        private string _dueDate = string.Empty;
        private double _sewerTapFeePaidAmount = 0;

        public double SewerTapFeeDueAmount { get => _sewerTapFeeDueAmount; set => _sewerTapFeeDueAmount = value; }
        public string DueDate { get => _dueDate; set => _dueDate = value; }
        public double SewerTapFeePaidAmount { get => _sewerTapFeePaidAmount; set => _sewerTapFeePaidAmount = value; }
    }
}
