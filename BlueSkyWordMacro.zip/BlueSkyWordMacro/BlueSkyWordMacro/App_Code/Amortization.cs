﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class Amortization
    {
        private DateTime _currentDate = DateTime.MaxValue;
        private String _currentMonth = string.Empty;
        private String _currentYear = string.Empty;
        private double _startBalance = 0;
        private double _payment = 0;
        private double _interestPercent = 0;
        private double _principalPayment = 0;
        private double _interestPayment = 0;
        private double _endBalance = 0;
        private double _totalPayments = 0;

        public DateTime CurrentDate { get => _currentDate; set => _currentDate = value; }
        public string CurrentMonth { get => _currentMonth; set => _currentMonth = value; }
        public string CurrentYear { get => _currentYear; set => _currentYear = value; }
        public double StartBalance { get => _startBalance; set => _startBalance = value; }
        public double Payment { get => _payment; set => _payment = value; }
        public double InterestPercent { get => _interestPercent; set => _interestPercent = value; }
        public double PrincipalPayment { get => _principalPayment; set => _principalPayment = value; }
        public double InterestPayment { get => _interestPayment; set => _interestPayment = value; }
        public double EndBalance { get => _endBalance; set => _endBalance = value; }
        public double TotalPayments { get => _totalPayments; set => _totalPayments = value; }

        public Amortization(DateTime currentDate, double startBalance, double payment, double interestPercent, double totalPayments)
        {
            _currentDate = currentDate;
            _currentMonth = getMonth();
            _currentYear = _currentDate.Year.ToString("0000");
            _startBalance = startBalance;
            _payment = payment;
            _interestPercent = interestPercent;
            _totalPayments = totalPayments;
            Calculate();

        }

        public void NextMonth()
        {
            _currentDate = _currentDate.AddMonths(1);
            _currentMonth = getMonth();
            _currentYear = _currentDate.Year.ToString("0000");
            _startBalance = _endBalance;
            Calculate();
        }

        private void Calculate()
        {
            _interestPayment = _startBalance * _interestPercent / 12;
            _principalPayment = _payment - _interestPayment;
            _endBalance = _startBalance - _principalPayment;

        }

        private string getMonth()
        {
            string returnValue = string.Empty;
            try
            {
                int intMonth = _currentDate.Month;

                switch(intMonth)
                {
                    case 1:
                        returnValue = "January";
                        break;
                    case 2:
                        returnValue = "February";
                        break;
                    case 3:
                        returnValue = "March";
                        break;
                    case 4:
                        returnValue = "April";
                        break;
                    case 5:
                        returnValue = "May";
                        break;
                    case 6:
                        returnValue = "June";
                        break;
                    case 7:
                        returnValue = "July";
                        break;
                    case 8:
                        returnValue = "August";
                        break;
                    case 9:
                        returnValue = "September";
                        break;
                    case 10:
                        returnValue = "October";
                        break;
                    case 11:
                        returnValue = "November";
                        break;
                    case 12:
                        returnValue = "December";
                        break;
                    default:
                        returnValue = "Unknown";
                        break;
                }
            }
            catch
            {
                returnValue = string.Empty;
            }
            return returnValue;
        }
    }
}
