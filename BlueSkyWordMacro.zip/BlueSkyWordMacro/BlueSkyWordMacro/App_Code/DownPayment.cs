﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class DownPayment
    {
        private double _downPaymentAmount = 0;
        private string _downPaymentDate = string.Empty;

        public double DownPaymentAmount { get => _downPaymentAmount; set => _downPaymentAmount = value; }
        public string DownPaymentDate { get => _downPaymentDate; set => _downPaymentDate = value; }
    }
}
