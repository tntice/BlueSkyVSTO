﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class NewCustomer
    {

        #region Variables

        private string _mowreyNumber = string.Empty;
        private DateTime _sellDate = DateTime.Now;
        private string _description = string.Empty;
        private string _townshipBorough = string.Empty;
        private string _county = string.Empty;
        private string _seller = string.Empty;
        private string _buyer = string.Empty;
        private string _address1 = string.Empty;
        private string _address2 = string.Empty;
        private string _cityStateZip = string.Empty;
        private string _phoneNumber = string.Empty;
        private string _email = string.Empty;
        private double _cashPrice = 0;
        private string _typeOwnership = "Regular";
        private IList<DownPayment> _downPayments = new List<DownPayment>();
        private double _financeAmount = 0;
        private double _termYears = 0;
        private double _interestRate = 0.12;
        private double _paymentAmount = 0;
        private string _firstPaymentDueDate = DateTime.Now.AddDays(30).ToShortDateString();
        private string _lastPaymentDueDate = string.Empty;
        private double _totalNumPayments = 0;
        private double _lateFeeAmount = 60;
        private IList<ClericalFee> _clericalFees = new List<ClericalFee>();
        private IList<TaxesDue> _taxesDues = new List<TaxesDue>();
        private IList<InsuranceDue> _insuranceDues = new List<InsuranceDue>();
        private IList<SewerTapFeeDue> _sewerTapFeeDues = new List<SewerTapFeeDue>();
        private IList<SewerSecurityDepositDue> _sewerSecurityDepositFeeDues = new List<SewerSecurityDepositDue>();
        private IList<OtherDue> _otherDues = new List<OtherDue>();
        private string _assessmentNumber = string.Empty;
        private double _principalPerMonth = 0;
        private double _interestPerMonth = 0;
        private double _totalActualPrice = 0;
        private double _sellersCost = 0;
        private string _sellersPurchaseDate = DateTime.Now.ToShortDateString();
        private string _sellersDBReference = string.Empty;
        private double _sellersProfit = 0;

        #endregion

        #region Properties

        public string MowreyNumber { get => _mowreyNumber; set => _mowreyNumber = value; }
        public DateTime SellDate { get => _sellDate; set => _sellDate = value; }
        public string Description { get => _description; set => _description = value; }
        public string TownshipBorough { get => _townshipBorough; set => _townshipBorough = value; }
        public string County { get => _county; set => _county = value; }
        public string Seller { get => _seller; set => _seller = value; }
        public string Buyer { get => _buyer; set => _buyer = value; }
        public string Address1 { get => _address1; set => _address1 = value; }
        public string Address2 { get => _address2; set => _address2 = value; }
        public string CityStateZip { get => _cityStateZip; set => _cityStateZip = value; }
        public string PhoneNumber { get => _phoneNumber; set => _phoneNumber = value; }
        public double CashPrice { get => _cashPrice; set => _cashPrice = value; }
        public string TypeOwnership { get => _typeOwnership; set => _typeOwnership = value; }
        public IList<DownPayment> DownPayments { get => _downPayments; set => _downPayments = value; }
        public double FinanceAmount { get => _financeAmount; set => _financeAmount = value; }
        public double TermYears { get => _termYears; set => _termYears = value; }
        public double InterestRate { get => _interestRate; set => _interestRate = value; }
        public double PaymentAmount { get => _paymentAmount; set => _paymentAmount = value; }
        public string FirstPaymentDueDate { get => _firstPaymentDueDate; set => _firstPaymentDueDate = value; }
        public string LastPaymentDueDate { get => _lastPaymentDueDate; set => _lastPaymentDueDate = value; }
        public double TotalNumPayments { get => _totalNumPayments; set => _totalNumPayments = value; }
        public double LateFeeAmount { get => _lateFeeAmount; set => _lateFeeAmount = value; }
        public IList<ClericalFee> ClericalFees { get => _clericalFees; set => _clericalFees = value; }
        public IList<TaxesDue> TaxesDues { get => _taxesDues; set => _taxesDues = value; }
        public IList<InsuranceDue> InsuranceDues { get => _insuranceDues; set => _insuranceDues = value; }
        public IList<SewerTapFeeDue> SewerTapFeeDues { get => _sewerTapFeeDues; set => _sewerTapFeeDues = value; }
        public IList<SewerSecurityDepositDue> SewerSecurityDepositFeeDues { get => _sewerSecurityDepositFeeDues; set => _sewerSecurityDepositFeeDues = value; }
        public IList<OtherDue> OtherDues { get => _otherDues; set => _otherDues = value; }
        public string AssessmentNumber { get => _assessmentNumber; set => _assessmentNumber = value; }
        public double PrincipalPerMonth { get => _principalPerMonth; set => _principalPerMonth = value; }
        public double InterestPerMonth { get => _interestPerMonth; set => _interestPerMonth = value; }
        public double TotalActualPrice { get => _totalActualPrice; set => _totalActualPrice = value; }
        public double SellersCost { get => _sellersCost; set => _sellersCost = value; }
        public string SellersPurchaseDate { get => _sellersPurchaseDate; set => _sellersPurchaseDate = value; }
        public string SellersDBReference { get => _sellersDBReference; set => _sellersDBReference = value; }
        public string Email { get => _email; set => _email = value; }
        public double SellersProfit { get => _sellersProfit; set => _sellersProfit = value; }

        #endregion

        #region Methods

        public double TotalDownpayment()
        {
            double returnValue = 0;
            try
            {
                foreach (DownPayment dwnPymt in DownPayments)
                {
                    returnValue += dwnPymt.DownPaymentAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalClericalFee()
        {
            double returnValue = 0;
            try
            {
                foreach (ClericalFee clFee in ClericalFees)
                {
                    
                    returnValue += clFee.ClericalFeeDueAmount;
                    returnValue -= clFee.ClericalFeePaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalTaxesDue()
        {
            double returnValue = 0;
            try
            {
                foreach(TaxesDue txDue in TaxesDues)
                {
                    returnValue += txDue.TaxesDueAmount;
                    returnValue -= txDue.TaxesPaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }
        
        public double TotalInsuranceDue()
        {
            double returnValue = 0;
            try
            {
                foreach (InsuranceDue iDue in InsuranceDues)
                {
                    returnValue += iDue.InsuranceDueAmount;
                    returnValue -= iDue.InsurancePaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalSewerTapFeeDue()
        {
            double returnValue = 0;
            try
            {
                foreach (SewerTapFeeDue sDue in SewerTapFeeDues)
                {
                    returnValue += sDue.SewerTapFeeDueAmount;
                    returnValue -= sDue.SewerTapFeePaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalSewerSecurityDepositDue()
        {
            double returnValue = 0;
            try
            {
                foreach (SewerSecurityDepositDue sDue in SewerSecurityDepositFeeDues)
                {
                    returnValue += sDue.SewerSecurityDepositDueAmount;
                    returnValue -= sDue.SewerSecurityDepositPaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalSewerSecurityDepositPaid()
        {
            double returnValue = 0;
            try
            {
                foreach (SewerSecurityDepositDue sDue in SewerSecurityDepositFeeDues)
                {
                    returnValue += sDue.SewerSecurityDepositPaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalOtherDue()
        {
            double returnValue = 0;
            try
            {
                foreach(OtherDue oDue in OtherDues)
                {
                    returnValue += oDue.OtherDueAmount;
                    returnValue -= oDue.OtherPaidAmount;
                }
            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }

        public double TotalFinanceAmount()
        {
            double returnValue = 0;
            try
            {
                returnValue = CashPrice;
                returnValue -= TotalDownpayment();
                returnValue += TotalClericalFee();
                returnValue += TotalTaxesDue();
                returnValue += TotalInsuranceDue();
                returnValue += TotalSewerTapFeeDue();
                returnValue += TotalSewerSecurityDepositDue();
                returnValue += TotalOtherDue();

            }
            catch
            {
                returnValue = 0;
            }
            return returnValue;
        }
        
        #endregion

    }
}
