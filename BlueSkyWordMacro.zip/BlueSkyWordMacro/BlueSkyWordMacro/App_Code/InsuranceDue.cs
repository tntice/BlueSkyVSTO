﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class InsuranceDue
    {
        private double _insuranceDueAmount = 0;
        private double _insurancePaidAmount = 0;
        private string _dueDate = string.Empty;

        public double InsuranceDueAmount { get => _insuranceDueAmount; set => _insuranceDueAmount = value; }
        public string DueDate { get => _dueDate; set => _dueDate = value; }
        public double InsurancePaidAmount { get => _insurancePaidAmount; set => _insurancePaidAmount = value; }
    }
}
