﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public class TaxesDue
    {
        private double _taxesDueAmount = 0;
        private double _taxesPaidAmount = 0;
        private string _dueDate = string.Empty;

        public double TaxesDueAmount { get => _taxesDueAmount; set => _taxesDueAmount = value; }
        public string DueDate { get => _dueDate; set => _dueDate = value; }
        public double TaxesPaidAmount { get => _taxesPaidAmount; set => _taxesPaidAmount = value; }
    }
}
