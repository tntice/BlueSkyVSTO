﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueSkyWordMacro
{
    public static class GlobalVars
    {
        private static int _mowreyNumber = 0;
        private static string _newCustomerFolder = string.Empty;
        private static NewCustomer _myNewCustomer = new NewCustomer();



        public static int MowreyNumber { get => _mowreyNumber; set => _mowreyNumber = value; }
        public static string NewCustomerFolder { get => _newCustomerFolder; set => _newCustomerFolder = value; }
        public static NewCustomer MyNewCustomer { get => _myNewCustomer; set => _myNewCustomer = value; }
    }

    public enum Counties
    {
        Adams,
        Allegheny,
        Armstrong,
        Beaver,
        Bedford,
        Berks,
        Blair,
        Bradford,
        Bucks,
        Butler,
        Cambria,
        Cameron,
        Carbon,
        Centre,
        Chester,
        Clarion,
        Clearfield,
        Clinton,
        Columbia,
        Crawford,
        Cumberland,
        Dauphin,
        Delaware,
        Elk,
        Erie,
        Fayette,
        Forest,
        Franklin,
        Fulton,
        Greene,
        Huntingdon,
        Indiana,
        Jefferson,
        Juniata,
        Lackawanna,
        Lancaster,
        Lawrence,
        Lebanon,
        Lehigh,
        Luzerne,
        Lycoming,
        McKean,
        Mercer,
        Mifflin,
        Monroe,
        Montgomery,
        Montour,
        Northampton,
        Northumberland,
        Perry,
        Philadelphia,
        Pike,
        Potter,
        Schuylkill,
        Snyder,
        Somerset,
        Sullivan,
        Susquehanna,
        Tioga,
        Union,
        Venango,
        Warren,
        Washington,
        Wayne,
        Westmoreland,
        Wyoming,
        York

    }

}
