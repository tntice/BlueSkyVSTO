﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;
using System.Windows.Forms;
using System.IO;


namespace BlueSkyWordMacro
{
    public static class BlueSkyDocuments
    {
        public static void CreateLandSaleSummary()
        {
            try
            {
                //Create an instance for word app
                Microsoft.Office.Interop.Word.Application winword = new Microsoft.Office.Interop.Word.Application();

                //Set animation status for word application
                winword.ShowAnimation = true;

                //Set status for word application is to be visible or not.
                winword.Visible = true;

                //Create a missing variable for missing value
                object missing = System.Reflection.Missing.Value;

                //Create a new document
                Microsoft.Office.Interop.Word.Document document = winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);

                //Get and set the margins
                float tm = document.PageSetup.TopMargin;
                float bm = document.PageSetup.BottomMargin;
                float lm = document.PageSetup.LeftMargin;
                float rm = document.PageSetup.RightMargin;

                tm = 36;
                bm = 36;
                lm = 36;
                rm = 36;

                document.PageSetup.TopMargin = tm;
                document.PageSetup.BottomMargin = bm;
                document.PageSetup.LeftMargin = lm;
                document.PageSetup.RightMargin = rm;

                //Add paragraph with Heading 1 style
                Microsoft.Office.Interop.Word.Paragraph para1 = document.Content.Paragraphs.Add(ref missing);
                object styleHeading1 = "Heading 1";
                para1.Range.set_Style(ref styleHeading1);
                para1.Range.Text = "LAND SALE SUMMARY";
                para1.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                para1.Range.InsertParagraphAfter();


                Paragraph para2 = document.Content.Paragraphs.Add(ref missing);
                para2.Range.Text = "";
                para2.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para2.Range.InsertParagraphAfter();


                //Create a 2X25 table and insert some dummy record
                Table firstTable = document.Tables.Add(para1.Range, 26, 2, ref missing, ref missing);

                firstTable.Borders.Enable = 0;

                firstTable.Columns[1].Width = 200;
                firstTable.Columns[2].Width = 325;

                firstTable.Rows[1].Cells[1].Range.Text = "DATE:";
                firstTable.Rows[1].Cells[2].Range.Text = GlobalVars.MyNewCustomer.SellDate.ToShortDateString();

                firstTable.Rows[2].Cells[1].Range.Text = "DESCRIPTION:";
                firstTable.Rows[2].Cells[2].Range.Text = GlobalVars.MyNewCustomer.Description.ToString();

                firstTable.Rows[3].Cells[1].Range.Text = "TOWNSHIP/BOROUGH:";
                firstTable.Rows[3].Cells[2].Range.Text = GlobalVars.MyNewCustomer.TownshipBorough.ToString();

                firstTable.Rows[4].Cells[1].Range.Text = "COUNTY:";
                firstTable.Rows[4].Cells[2].Range.Text = GlobalVars.MyNewCustomer.County.ToString();

                firstTable.Rows[5].Cells[1].Range.Text = "MOWREY MAP:";
                firstTable.Rows[5].Cells[2].Range.Text = GlobalVars.MyNewCustomer.MowreyNumber.ToString();

                firstTable.Rows[6].Cells[1].Range.Text = "SELLER:";
                firstTable.Rows[6].Cells[2].Range.Text = GlobalVars.MyNewCustomer.Seller.ToString();

                firstTable.Rows[7].Cells[1].Range.Text = "BUYER:";
                firstTable.Rows[7].Cells[2].Range.Text = GlobalVars.MyNewCustomer.Buyer.ToString();

                string address = GlobalVars.MyNewCustomer.Address1.ToString();
                if (GlobalVars.MyNewCustomer.Address2.Length > 0)
                {
                    address += Environment.NewLine + GlobalVars.MyNewCustomer.Address2.ToString();
                }
                firstTable.Rows[8].Cells[1].Range.Text = "STREET ADDRESS:";
                firstTable.Rows[8].Cells[2].Range.Text = address;

                firstTable.Rows[9].Cells[1].Range.Text = "CITY, STATE, ZIP:";
                firstTable.Rows[9].Cells[2].Range.Text = GlobalVars.MyNewCustomer.CityStateZip.ToString();
                
                firstTable.Rows[10].Cells[1].Range.Text = "PHONE NUMBERS:";
                firstTable.Rows[10].Cells[2].Range.Text = GlobalMethods.LineBreakPhoneNumber(GlobalVars.MyNewCustomer.PhoneNumber);

                firstTable.Rows[11].Cells[1].Range.Text = "CASH PRICE:";
                firstTable.Rows[11].Cells[2].Range.Text = GlobalVars.MyNewCustomer.CashPrice.ToString("c");

                firstTable.Rows[12].Cells[1].Range.Text = "DOWNPAYMENT AMOUNT:";
                firstTable.Rows[12].Cells[2].Range.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c");

                firstTable.Rows[13].Cells[1].Range.Text = "FINANCE AMOUNT:";
                firstTable.Rows[13].Cells[2].Range.Text = GlobalVars.MyNewCustomer.FinanceAmount.ToString("c");

                firstTable.Rows[14].Cells[1].Range.Text = "TERM:";
                firstTable.Rows[14].Cells[2].Range.Text = GlobalVars.MyNewCustomer.TermYears.ToString("0.0") + " Years";

                firstTable.Rows[15].Cells[1].Range.Text = "INTEREST RATE:";
                firstTable.Rows[15].Cells[2].Range.Text = GlobalVars.MyNewCustomer.InterestRate.ToString("0.000");

                firstTable.Rows[16].Cells[1].Range.Text = "PAYMENT AMOUNT";
                firstTable.Rows[16].Cells[2].Range.Text = GlobalVars.MyNewCustomer.PaymentAmount.ToString("c");

                firstTable.Rows[17].Cells[1].Range.Text = "1ST PAYMENT DUE:";
                firstTable.Rows[17].Cells[2].Range.Text = GlobalVars.MyNewCustomer.FirstPaymentDueDate.ToString();

                firstTable.Rows[18].Cells[1].Range.Text = "LAST PAYMENT DUE:";
                firstTable.Rows[18].Cells[2].Range.Text = GlobalVars.MyNewCustomer.LastPaymentDueDate.ToString();

                firstTable.Rows[19].Cells[1].Range.Text = "TOTAL # OF PAYMENTS:";
                firstTable.Rows[19].Cells[2].Range.Text = GlobalVars.MyNewCustomer.TotalNumPayments.ToString("0.00");

                firstTable.Rows[20].Cells[1].Range.Text = "PRINCIPAL PER MONTH:";
                firstTable.Rows[20].Cells[2].Range.Text = GlobalVars.MyNewCustomer.PrincipalPerMonth.ToString("c");

                firstTable.Rows[21].Cells[1].Range.Text = "INTEREST PER MONTH:";
                firstTable.Rows[21].Cells[2].Range.Text = GlobalVars.MyNewCustomer.InterestPerMonth.ToString("c");

                firstTable.Rows[22].Cells[1].Range.Text = "TOTAL SALES PRICE INCL INTEREST FOR FULL TERM:";
                firstTable.Rows[22].Cells[2].Range.Text = GlobalVars.MyNewCustomer.TotalActualPrice.ToString("c");               

                firstTable.Rows[23].Cells[1].Range.Text = "SELLER'S COST:";
                firstTable.Rows[23].Cells[2].Range.Text = GlobalVars.MyNewCustomer.SellersCost.ToString("c");

                Double dblSellerCost = GlobalVars.MyNewCustomer.TotalActualPrice - GlobalVars.MyNewCustomer.SellersCost;

                firstTable.Rows[24].Cells[1].Range.Text = "SELLER'S PROFIT";
                firstTable.Rows[24].Cells[2].Range.Text = dblSellerCost.ToString("c");

                firstTable.Rows[25].Cells[1].Range.Text = "SELLER'S PURCHASE DATE:";
                firstTable.Rows[25].Cells[2].Range.Text = GlobalVars.MyNewCustomer.SellersPurchaseDate.ToString();

                firstTable.Rows[26].Cells[1].Range.Text = "SELLER'S DB REFERENCE:";
                firstTable.Rows[26].Cells[2].Range.Text = GlobalVars.MyNewCustomer.SellersDBReference.ToString();

                foreach (Row row in firstTable.Rows)
                {
                    foreach (Cell cell in row.Cells)
                    {
                        if (cell.ColumnIndex == 1)
                        {
                            cell.Range.Font.Bold = 1;
                        }
                        cell.Range.Font.Size = 12;
                    }
                }


                //Save the document
                object filename = Path.Combine(GlobalVars.NewCustomerFolder, GlobalVars.MyNewCustomer.Buyer + "-LandSaleSummary.docx");
                string strFileName = Convert.ToString(filename);
                if (File.Exists(strFileName))
                {
                    File.Delete(strFileName);
                }
                document.SaveAs2(ref filename);
                document.Close(ref missing, ref missing, ref missing);
                document = null;
                winword.Quit(ref missing, ref missing, ref missing);
                winword = null;

            }
            catch(Exception ex)
            {
                MessageBox.Show("Land Sale Summary could not be created."  + Environment.NewLine + ex.Message);
            }
        }

        public static void CreatePaysheet()
        {

            //Create an instance for word app
            Microsoft.Office.Interop.Word.Application winword = new Microsoft.Office.Interop.Word.Application();


            //Set animation status for word application
            winword.ShowAnimation = true;

            //Set status for word application is to be visible or not.
            winword.Visible = true;

            //Create a missing variable for missing value
            object missing = System.Reflection.Missing.Value;

            //Create a new document
            Microsoft.Office.Interop.Word.Document document = winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);

            try
            {
                //Get and set the margins
                float tm = 18;
                float bm = 18;
                float lm = 18;
                float rm = 18;

                document.PageSetup.TopMargin = tm;
                document.PageSetup.BottomMargin = bm;
                document.PageSetup.LeftMargin = lm;
                document.PageSetup.RightMargin = rm;


                Paragraph para1 = document.Content.Paragraphs.Add(ref missing);
                para1.Range.Text = "";
                para1.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para1.Range.ParagraphFormat.SpaceAfter = 0;
                para1.Range.InsertParagraphAfter();


                //Create a 2X8 table and insert some dummy record
                Table firstTable = document.Tables.Add(para1.Range, 8, 2, ref missing, ref missing);

                firstTable.Borders.Enable = 0;

                firstTable.Columns[1].Width = 250;
                firstTable.Columns[2].Width = 300;


                object styleHeading1 = "Heading 2";

                firstTable.Rows[1].Cells[1].Range.set_Style(ref styleHeading1);
                firstTable.Rows[1].Cells[1].Range.Text = GlobalVars.MyNewCustomer.Description + ", " + GlobalVars.MyNewCustomer.TownshipBorough + ", " + " CO: " + GlobalVars.MyNewCustomer.County;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[1].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[1].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[1].Cells[1].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[1].Cells[2].Range.set_Style(ref styleHeading1);
                firstTable.Rows[1].Cells[2].Range.Text = GlobalVars.MyNewCustomer.Buyer;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[1].Cells[2].Range.Font.Bold = 1;
                firstTable.Rows[1].Cells[2].Range.Font.Size = 14;
                firstTable.Rows[1].Cells[2].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[2].Cells[1].Range.Text = GlobalVars.MyNewCustomer.CashPrice.ToString("c") + " Cash Price";
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[2].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                string thisAddress = string.Empty;
                if (GlobalVars.MyNewCustomer.Address2.Trim().Length > 0)
                {
                    thisAddress = GlobalVars.MyNewCustomer.Address1 + Environment.NewLine + GlobalVars.MyNewCustomer.Address2;
                }
                else
                {
                    thisAddress = GlobalVars.MyNewCustomer.Address1;
                }
                firstTable.Rows[2].Cells[2].Range.Text = thisAddress;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[2].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                string _dwnpmt = string.Empty;
                int i = 1;
                foreach (DownPayment dwn in GlobalVars.MyNewCustomer.DownPayments)
                {
                    _dwnpmt += dwn.DownPaymentAmount.ToString("c") + " Down Payment Due " + dwn.DownPaymentDate.ToString();
                    if (i < GlobalVars.MyNewCustomer.DownPayments.Count)
                    {
                        _dwnpmt += Environment.NewLine;
                    }
                    i += 1;
                }
                firstTable.Rows[3].Cells[1].Range.Text = _dwnpmt;
                //if (GlobalVars.MyNewCustomer.DownPayments.Count > 0)
                //{
                //    firstTable.Rows[3].Cells[1].Range.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c") + " Down Payment Due " + GlobalVars.MyNewCustomer.DownPayments[0].DownPaymentDate.ToString();
                //}
                //else
                //{
                //    firstTable.Rows[3].Cells[1].Range.Text = "$0.00 Down Payment.";
                //}
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[3].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;


                firstTable.Rows[3].Cells[2].Range.Text = GlobalVars.MyNewCustomer.CityStateZip;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[3].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;


                string Fees = string.Empty;

                Fees = GlobalVars.MyNewCustomer.TotalTaxesDue().ToString("c") + " Balance Taxes Due " + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalSewerTapFeeDue().ToString("c") + " Balance Water/Sewer Tap Due" + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalSewerSecurityDepositDue().ToString("c") + " Balance Water/Sewer Security Deposit" + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalInsuranceDue().ToString("c") + " Balance Insurance Due" + Environment.NewLine;

                foreach (OtherDue od in GlobalVars.MyNewCustomer.OtherDues)
                {
                    Fees += (od.OtherDueAmount - od.OtherPaidAmount).ToString("c") + " Balance " + od.Description + " Due" + Environment.NewLine;
                }

                Fees += GlobalVars.MyNewCustomer.TotalClericalFee().ToString("c") + " Balance Clerical Fee Due";

                firstTable.Rows[4].Cells[1].Range.Text = Fees;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[4].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[4].Cells[2].Range.Text = GlobalMethods.LineBreakPhoneNumber(GlobalVars.MyNewCustomer.PhoneNumber) + Environment.NewLine + GlobalVars.MyNewCustomer.Email;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[4].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                string strValue = GlobalVars.MyNewCustomer.FinanceAmount.ToString("c") + " Balance financing for ";
                strValue += GlobalVars.MyNewCustomer.TermYears.ToString() + " years @ ";
                strValue += (GlobalVars.MyNewCustomer.InterestRate * 100).ToString("00") + "% simple annual interest";

                firstTable.Rows[5].Cells[1].Range.Text = strValue;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[5].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[6].Cells[1].Range.Text = "Paying " + GlobalVars.MyNewCustomer.PaymentAmount.ToString("c") + " per month from";
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[6].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[6].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[6].Cells[2].Range.Text = "*" + GlobalVars.MyNewCustomer.LateFeeAmount.ToString("c") + " LATE FEE";
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[6].Cells[2].Range.Font.Size = 14;
                firstTable.Rows[6].Cells[2].Range.Font.Bold = 1;
                firstTable.Rows[6].Cells[2].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[7].Cells[1].Range.Text = GlobalVars.MyNewCustomer.FirstPaymentDueDate + " to " + GlobalVars.MyNewCustomer.LastPaymentDueDate;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[7].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[7].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[8].Cells[1].Range.Text = "(" + GlobalVars.MyNewCustomer.TotalNumPayments.ToString() + " monthly payments - " + GlobalVars.MyNewCustomer.TermYears.ToString() + " year plan)";
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[8].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;


                firstTable.Rows[8].Cells[2].Range.Text = "Paid " + GlobalVars.MyNewCustomer.TotalSewerSecurityDepositPaid().ToString("c") + " Water & Sewer Security Deposit";
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[8].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                //Second Table
                Paragraph para2 = document.Content.Paragraphs.Add(ref missing);
                para2.Range.Text = "";
                para2.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para2.Range.ParagraphFormat.SpaceAfter = 0;
                para2.Range.InsertParagraphAfter();

                //Create a 2X8 table and insert some dummy record
                Table secondTable = document.Tables.Add(para2.Range, 1, 10, ref missing, ref missing);

                secondTable.Borders.Enable = 7;

                secondTable.Columns[1].Width = 55;
                secondTable.Columns[2].Width = 70;
                secondTable.Columns[3].Width = 80;
                secondTable.Columns[4].Width = 60;
                secondTable.Columns[5].Width = 40;
                secondTable.Columns[6].Width = 35;
                secondTable.Columns[7].Width = 35;
                secondTable.Columns[8].Width = 65;
                secondTable.Columns[9].Width = 40;
                secondTable.Columns[10].Width = 70;

                secondTable.Rows[1].Cells[1].Range.Text = "Finance" + Environment.NewLine + "Amount";
                secondTable.Rows[1].Cells[1].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[2].Range.Text = GlobalVars.MyNewCustomer.FinanceAmount.ToString("c");
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[2].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[3].Range.Text = "Actual Selling Price, Including Principal, Interest, and Down Payment";
                secondTable.Rows[1].Cells[3].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[3].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[3].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[4].Range.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c");
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[4].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[5].Range.Text = "Down for";
                secondTable.Rows[1].Cells[5].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[5].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[5].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[6].Range.Text = GlobalVars.MyNewCustomer.TermYears.ToString("00.0");
                secondTable.Rows[1].Cells[6].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[6].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[6].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[7].Range.Text = "Years @ " + (GlobalVars.MyNewCustomer.InterestRate * 100).ToString() + "%";
                secondTable.Rows[1].Cells[7].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[7].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[7].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[8].Range.Text = GlobalVars.MyNewCustomer.PaymentAmount.ToString("c");
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[8].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[9].Range.Text = "per month";
                secondTable.Rows[1].Cells[9].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[9].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[9].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[10].Range.Text = GlobalVars.MyNewCustomer.TotalActualPrice.ToString("c");
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[10].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.SpaceAfter = 0;

                //Third Table
                Paragraph para3 = document.Content.Paragraphs.Add(ref missing);
                para3.Range.Text = "";
                para3.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para3.Range.ParagraphFormat.SpaceAfter = 0;
                para3.Range.InsertParagraphAfter();

                //Create a 2X8 table and insert some dummy record
                Table thirdTable = document.Tables.Add(para3.Range, 26, 9, ref missing, ref missing);

                thirdTable.Borders.Enable = 7;

                thirdTable.Columns[1].Width = 64;
                thirdTable.Columns[2].Width = 38;
                thirdTable.Columns[3].Width = 64;
                thirdTable.Columns[4].Width = 64;
                thirdTable.Columns[5].Width = 64;
                thirdTable.Columns[6].Width = 64;
                thirdTable.Columns[7].Width = 64;
                thirdTable.Columns[8].Width = 64;
                thirdTable.Columns[9].Width = 64;

                thirdTable.Rows[1].Cells[1].Range.Text = "Check #";
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[1].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[2].Range.Text = "Pmt #";
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[2].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[3].Range.Text = "Month/Year";
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[3].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[4].Range.Text = "Date";
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[4].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[5].Range.Text = "Taxes";
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[5].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[6].Range.Text = "Misc Fees";
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[6].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[7].Range.Text = "Previous Balance";
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[7].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[8].Range.Text = "Payment";
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[8].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[9].Range.Text = "Current Balance";
                thirdTable.Rows[1].Cells[9].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                thirdTable.Rows[1].Cells[9].Range.Font.Size = 10;
                thirdTable.Rows[1].Cells[9].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[9].Range.ParagraphFormat.SpaceAfter = 0;


                //Save the document
                object filename = Path.Combine(GlobalVars.NewCustomerFolder, GlobalVars.MyNewCustomer.Buyer + "-Paysheet.docx");
                string strFileName = Convert.ToString(filename);
                if (File.Exists(strFileName))
                {
                    File.Delete(strFileName);
                }
                document.SaveAs2(ref filename);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                document.Close(ref missing, ref missing, ref missing);
                document = null;
                winword.Quit(ref missing, ref missing, ref missing);
                winword = null;
            }
        }

        private static int NewMethod()
        {
            return 1;
        }

        public static void CreateAmortizationSheet()
        {

            //Create an instance for word app
            Microsoft.Office.Interop.Word.Application winword = new Microsoft.Office.Interop.Word.Application();


            //Set animation status for word application
            winword.ShowAnimation = true;

            //Set status for word application is to be visible or not.
            winword.Visible = true;

            //Create a missing variable for missing value
            object missing = System.Reflection.Missing.Value;

            //Create a new document
            Microsoft.Office.Interop.Word.Document document = winword.Documents.Add(ref missing, ref missing, ref missing, ref missing);

            try
            {
                //Get and set the margins
                float tm = 18;
                float bm = 18;
                float lm = 18;
                float rm = 18;

                document.PageSetup.TopMargin = tm;
                document.PageSetup.BottomMargin = bm;
                document.PageSetup.LeftMargin = lm;
                document.PageSetup.RightMargin = rm;


                Paragraph para1 = document.Content.Paragraphs.Add(ref missing);
                para1.Range.Text = "";
                para1.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para1.Range.ParagraphFormat.SpaceAfter = 0;
                para1.Range.InsertParagraphAfter();


                //Create a 2X8 table and insert some dummy record
                Table firstTable = document.Tables.Add(para1.Range, 8, 2, ref missing, ref missing);

                firstTable.Borders.Enable = 0;

                firstTable.Columns[1].Width = 250;
                firstTable.Columns[2].Width = 300;


                object styleHeading1 = "Heading 2";

                firstTable.Rows[1].Cells[1].Range.set_Style(ref styleHeading1);
                firstTable.Rows[1].Cells[1].Range.Text = GlobalVars.MyNewCustomer.Description + ", " + GlobalVars.MyNewCustomer.TownshipBorough + ", " + " CO: " + GlobalVars.MyNewCustomer.County;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[1].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[1].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[1].Cells[1].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[1].Cells[2].Range.set_Style(ref styleHeading1);
                firstTable.Rows[1].Cells[2].Range.Text = GlobalVars.MyNewCustomer.Buyer;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[1].Cells[2].Range.Font.Bold = 1;
                firstTable.Rows[1].Cells[2].Range.Font.Size = 14;
                firstTable.Rows[1].Cells[2].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[2].Cells[1].Range.Text = GlobalVars.MyNewCustomer.CashPrice.ToString("c") + " Cash Price";
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[2].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[2].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                string thisAddress = string.Empty;
                if (GlobalVars.MyNewCustomer.Address2.Trim().Length > 0)
                {
                    thisAddress = GlobalVars.MyNewCustomer.Address1 + Environment.NewLine + GlobalVars.MyNewCustomer.Address2;
                }
                else
                {
                    thisAddress = GlobalVars.MyNewCustomer.Address1;
                }
                firstTable.Rows[2].Cells[2].Range.Text = thisAddress;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[2].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[2].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;



                string _dwnpmt = string.Empty;
                int j = 1;
                foreach (DownPayment dwn in GlobalVars.MyNewCustomer.DownPayments)
                {
                    _dwnpmt += dwn.DownPaymentAmount.ToString("c") + " Down Payment Due " + dwn.DownPaymentDate.ToString();
                    if (j < GlobalVars.MyNewCustomer.DownPayments.Count)
                    {
                        _dwnpmt += Environment.NewLine;
                    }
                    j += 1;
                }
                firstTable.Rows[3].Cells[1].Range.Text = _dwnpmt;
                //if (GlobalVars.MyNewCustomer.DownPayments.Count > 0)
                //{
                //    firstTable.Rows[3].Cells[1].Range.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c") + " Down Payment Due " + GlobalVars.MyNewCustomer.DownPayments[0].DownPaymentDate.ToString();
                //}
                //else
                //{
                //    firstTable.Rows[3].Cells[1].Range.Text = "$0.00 Down Payment.";
                //}
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[3].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[3].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;


                firstTable.Rows[3].Cells[2].Range.Text = GlobalVars.MyNewCustomer.CityStateZip;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[3].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[3].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;


                string Fees = string.Empty;

                Fees = GlobalVars.MyNewCustomer.TotalTaxesDue().ToString("c") + " Balance Taxes Due " + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalSewerTapFeeDue().ToString("c") + " Balance Water/Sewer Tap Due" + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalSewerSecurityDepositDue().ToString("c") + " Balance Water/Sewer Security Deposit" + Environment.NewLine;
                Fees += GlobalVars.MyNewCustomer.TotalInsuranceDue().ToString("c") + " Balance Insurance Due" + Environment.NewLine;

                foreach (OtherDue od in GlobalVars.MyNewCustomer.OtherDues)
                {
                    Fees += (od.OtherDueAmount - od.OtherPaidAmount).ToString("c") + " Balance " + od.Description + " Due" + Environment.NewLine;
                }

                Fees += GlobalVars.MyNewCustomer.TotalClericalFee().ToString("c") + " Balance Clerical Fee Due";

                firstTable.Rows[4].Cells[1].Range.Text = Fees;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[4].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[4].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[4].Cells[2].Range.Text = GlobalMethods.LineBreakPhoneNumber(GlobalVars.MyNewCustomer.PhoneNumber) + Environment.NewLine + GlobalVars.MyNewCustomer.Email;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[4].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[4].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                string strValue = GlobalVars.MyNewCustomer.FinanceAmount.ToString("c") + " Balance financing for ";
                strValue += GlobalVars.MyNewCustomer.TermYears.ToString() + " years @ ";
                strValue += (GlobalVars.MyNewCustomer.InterestRate * 100).ToString("00") + "% simple annual interest";

                firstTable.Rows[5].Cells[1].Range.Text = strValue;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[5].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[5].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[6].Cells[1].Range.Text = "Paying " + GlobalVars.MyNewCustomer.PaymentAmount.ToString("c") + " per month from";
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[6].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[6].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[6].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[6].Cells[2].Range.Text = "*" + GlobalVars.MyNewCustomer.LateFeeAmount.ToString("c") + " LATE FEE";
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[6].Cells[2].Range.Font.Size = 14;
                firstTable.Rows[6].Cells[2].Range.Font.Bold = 1;
                firstTable.Rows[6].Cells[2].Range.HighlightColorIndex = WdColorIndex.wdYellow;
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[6].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[7].Cells[1].Range.Text = GlobalVars.MyNewCustomer.FirstPaymentDueDate + " to " + GlobalVars.MyNewCustomer.LastPaymentDueDate;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[7].Cells[1].Range.Font.Size = 14;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[7].Cells[1].Range.Font.Bold = 1;
                firstTable.Rows[7].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                firstTable.Rows[8].Cells[1].Range.Text = "(" + GlobalVars.MyNewCustomer.TotalNumPayments.ToString() + " monthly payments - " + GlobalVars.MyNewCustomer.TermYears.ToString() + " year plan)";
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                firstTable.Rows[8].Cells[1].Range.Font.Size = 12;
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[8].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;


                firstTable.Rows[8].Cells[2].Range.Text = "Paid " + GlobalVars.MyNewCustomer.TotalSewerSecurityDepositPaid().ToString("c") + " Water & Sewer Security Deposit";
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphRight;
                firstTable.Rows[8].Cells[2].Range.Font.Size = 12;
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                firstTable.Rows[8].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                //Second Table
                Paragraph para2 = document.Content.Paragraphs.Add(ref missing);
                para2.Range.Text = "";
                para2.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para2.Range.ParagraphFormat.SpaceAfter = 0;
                para2.Range.InsertParagraphAfter();

                //Create a 2X8 table and insert some dummy record
                Table secondTable = document.Tables.Add(para2.Range, 1, 10, ref missing, ref missing);

                secondTable.Borders.Enable = 7;

                secondTable.Columns[1].Width = 55;
                secondTable.Columns[2].Width = 70;
                secondTable.Columns[3].Width = 80;
                secondTable.Columns[4].Width = 60;
                secondTable.Columns[5].Width = 40;
                secondTable.Columns[6].Width = 35;
                secondTable.Columns[7].Width = 35;
                secondTable.Columns[8].Width = 65;
                secondTable.Columns[9].Width = 40;
                secondTable.Columns[10].Width = 70;

                secondTable.Rows[1].Cells[1].Range.Text = "Finance" + Environment.NewLine + "Amount";
                secondTable.Rows[1].Cells[1].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[2].Range.Text = GlobalVars.MyNewCustomer.FinanceAmount.ToString("c");
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[2].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[3].Range.Text = "Actual Selling Price, Including Principal, Interest, and Down Payment";
                secondTable.Rows[1].Cells[3].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[3].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[3].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[4].Range.Text = GlobalVars.MyNewCustomer.TotalDownpayment().ToString("c");
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[4].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[4].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[5].Range.Text = "Down for";
                secondTable.Rows[1].Cells[5].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[5].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[5].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[6].Range.Text = GlobalVars.MyNewCustomer.TermYears.ToString("00.0");
                secondTable.Rows[1].Cells[6].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[6].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[6].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[7].Range.Text = "Years @ " + (GlobalVars.MyNewCustomer.InterestRate * 100).ToString() + "%";
                secondTable.Rows[1].Cells[7].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[7].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[7].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[8].Range.Text = GlobalVars.MyNewCustomer.PaymentAmount.ToString("c");
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[8].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[8].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[9].Range.Text = "per month";
                secondTable.Rows[1].Cells[9].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[9].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[9].Range.ParagraphFormat.SpaceAfter = 0;

                secondTable.Rows[1].Cells[10].Range.Text = GlobalVars.MyNewCustomer.TotalActualPrice.ToString("c");
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphCenter;
                secondTable.Rows[1].Cells[10].Range.Font.Size = 10;
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.LineSpacing = 12;
                secondTable.Rows[1].Cells[10].Range.ParagraphFormat.SpaceAfter = 0;

                //Third Table
                Paragraph para3 = document.Content.Paragraphs.Add(ref missing);
                para3.Range.Text = "";
                para3.Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                para3.Range.ParagraphFormat.SpaceAfter = 0;
                para3.Range.InsertParagraphAfter();

                //Create a 2X8 table and insert some dummy record
                Table thirdTable = document.Tables.Add(para3.Range, Convert.ToInt32(GlobalVars.MyNewCustomer.TotalNumPayments + 1), 8, ref missing, ref missing);

                thirdTable.Borders.Enable = 0;

                Int32 fontSize = 12;

                thirdTable.Columns[1].Width = 45;
                thirdTable.Columns[2].Width = 80;
                thirdTable.Columns[3].Width = 50;
                thirdTable.Columns[4].Width = 75;
                thirdTable.Columns[5].Width = 75;
                thirdTable.Columns[6].Width = 75;
                thirdTable.Columns[7].Width = 75;
                thirdTable.Columns[8].Width = 75;

                thirdTable.Rows[1].Cells[1].Range.Text = "Pmt #";
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[1].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[2].Range.Text = "Month";
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[2].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[3].Range.Text = "Year";
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[3].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[3].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[4].Range.Text = "Balance";
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[4].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[4].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[5].Range.Text = "Payment";
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[5].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[5].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[6].Range.Text = "Principal";
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[6].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[6].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[7].Range.Text = "Interest";
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[7].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[7].Range.ParagraphFormat.SpaceAfter = 0;

                thirdTable.Rows[1].Cells[8].Range.Text = "Balance";
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                thirdTable.Rows[1].Cells[8].Range.Font.Size = fontSize;
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.LineSpacing = 12;
                thirdTable.Rows[1].Cells[8].Range.ParagraphFormat.SpaceAfter = 0;

                if (GlobalMethods.IsValidDateTime(GlobalVars.MyNewCustomer.FirstPaymentDueDate))
                {
                    Amortization amort = new Amortization(Convert.ToDateTime(GlobalVars.MyNewCustomer.FirstPaymentDueDate),
                        GlobalVars.MyNewCustomer.FinanceAmount, GlobalVars.MyNewCustomer.PaymentAmount,
                        GlobalVars.MyNewCustomer.InterestRate, GlobalVars.MyNewCustomer.TotalNumPayments);


                    for (int i = 2; i < Convert.ToInt32(GlobalVars.MyNewCustomer.TotalNumPayments + 2); i = i + 1)
                    {
                        thirdTable.Rows[i].Cells[1].Range.Text = (i - 1).ToString();
                        thirdTable.Rows[i].Cells[1].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[1].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[1].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[1].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[2].Range.Text = amort.CurrentMonth;
                        thirdTable.Rows[i].Cells[2].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[2].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[2].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[2].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[3].Range.Text = amort.CurrentYear;
                        thirdTable.Rows[i].Cells[3].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[3].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[3].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[3].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[4].Range.Text = amort.StartBalance.ToString("c");
                        thirdTable.Rows[i].Cells[4].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[4].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[4].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[4].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[5].Range.Text = GlobalVars.MyNewCustomer.PaymentAmount.ToString("c");
                        thirdTable.Rows[i].Cells[5].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[5].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[5].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[5].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[6].Range.Text = amort.PrincipalPayment.ToString("c");
                        thirdTable.Rows[i].Cells[6].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[6].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[6].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[6].Range.ParagraphFormat.SpaceAfter = 0;
                        
                        thirdTable.Rows[i].Cells[7].Range.Text = amort.InterestPayment.ToString("c");
                        thirdTable.Rows[i].Cells[7].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[7].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[7].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[7].Range.ParagraphFormat.SpaceAfter = 0;

                        thirdTable.Rows[i].Cells[8].Range.Text = amort.EndBalance.ToString("c");
                        thirdTable.Rows[i].Cells[8].Range.ParagraphFormat.Alignment = WdParagraphAlignment.wdAlignParagraphLeft;
                        thirdTable.Rows[i].Cells[8].Range.Font.Size = fontSize;
                        thirdTable.Rows[i].Cells[8].Range.ParagraphFormat.LineSpacing = 12;
                        thirdTable.Rows[i].Cells[8].Range.ParagraphFormat.SpaceAfter = 0;



                        amort.NextMonth();

                    }

                }


                //Save the document
                object filename = Path.Combine(GlobalVars.NewCustomerFolder, GlobalVars.MyNewCustomer.Buyer + "-Amortization.docx");
                string strFileName = Convert.ToString(filename);
                if (File.Exists(strFileName))
                {
                    File.Delete(strFileName);
                }
                document.SaveAs2(ref filename);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                document.Close(ref missing, ref missing, ref missing);
                document = null;
                winword.Quit(ref missing, ref missing, ref missing);
                winword = null;
            }
        }
    }
}
