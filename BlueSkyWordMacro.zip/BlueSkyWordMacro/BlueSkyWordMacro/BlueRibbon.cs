﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using System.Configuration;
using System.Windows.Forms;
using BlueSkyWordMacro.WinForms.NewCustomer;


namespace BlueSkyWordMacro
{
    public partial class BlueRibbon
    {
        private void BlueRibbon_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void btnNewCustomer_Click(object sender, RibbonControlEventArgs e)
        {
            GlobalVars.MowreyNumber = Convert.ToInt32(ConfigurationManager.AppSettings["MowreyNumber"].ToString());
            GlobalVars.NewCustomerFolder = ConfigurationManager.AppSettings["NewCustomerFolder"].ToString();

            //MessageBox.Show(GlobalVars.MowreyNumber.ToString());
            //TestDocument.CreateDocument();
            frmNewCustomer1 frm1 = new frmNewCustomer1();
            frm1.Show();



        }
    }
}
