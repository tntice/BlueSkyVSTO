﻿namespace BlueSkyWordMacro
{
    partial class BlueRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public BlueRibbon()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabBlueSky = this.Factory.CreateRibbonTab();
            this.groupBlueSky = this.Factory.CreateRibbonGroup();
            this.btnNewCustomer = this.Factory.CreateRibbonButton();
            this.tabBlueSky.SuspendLayout();
            this.groupBlueSky.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabBlueSky
            // 
            this.tabBlueSky.Groups.Add(this.groupBlueSky);
            this.tabBlueSky.Label = "Blue Sky";
            this.tabBlueSky.Name = "tabBlueSky";
            // 
            // groupBlueSky
            // 
            this.groupBlueSky.Items.Add(this.btnNewCustomer);
            this.groupBlueSky.Label = "Macros";
            this.groupBlueSky.Name = "groupBlueSky";
            // 
            // btnNewCustomer
            // 
            this.btnNewCustomer.Image = global::BlueSkyWordMacro.Properties.Resources.TextFile32;
            this.btnNewCustomer.Label = "New Customer";
            this.btnNewCustomer.Name = "btnNewCustomer";
            this.btnNewCustomer.ShowImage = true;
            this.btnNewCustomer.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnNewCustomer_Click);
            // 
            // BlueRibbon
            // 
            this.Name = "BlueRibbon";
            this.RibbonType = "Microsoft.Word.Document";
            this.Tabs.Add(this.tabBlueSky);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.BlueRibbon_Load);
            this.tabBlueSky.ResumeLayout(false);
            this.tabBlueSky.PerformLayout();
            this.groupBlueSky.ResumeLayout(false);
            this.groupBlueSky.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tabBlueSky;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup groupBlueSky;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnNewCustomer;
    }

    partial class ThisRibbonCollection
    {
        internal BlueRibbon BlueRibbon
        {
            get { return this.GetRibbon<BlueRibbon>(); }
        }
    }
}
